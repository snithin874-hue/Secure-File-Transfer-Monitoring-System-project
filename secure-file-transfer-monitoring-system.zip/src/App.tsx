/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  LayoutDashboard, 
  ListCollapse, 
  Settings, 
  ShieldAlert, 
  FileCheck, 
  FileText, 
  Terminal, 
  Activity,
  Download,
  Shield,
  Clock
} from "lucide-react";

import { SFTMSEvent } from "./types";
import { INITIAL_EVENTS } from "./data/mockEvents";

// Sub-components
import DashboardOverview from "./components/DashboardOverview";
import LiveLogViewer from "./components/LiveLogViewer";
import PolicyManager from "./components/PolicyManager";
import IntegrityCheck from "./components/IntegrityCheck";
import AuditReport from "./components/AuditReport";
import PythonScriptsViewer from "./components/PythonScriptsViewer";

export default function App() {
  // Navigation active tab
  const [activeTab, setActiveTab] = useState<string>("dashboard");

  // Shared application state: File Transfer Event Logs
  const [events, setEvents] = useState<SFTMSEvent[]>(INITIAL_EVENTS);

  // Shared Policy Engine Configurations
  const [sensitiveDirs, setSensitiveDirs] = useState<string[]>([
    "/etc/shadow",
    "/etc/pam.d",
    "/var/secure",
    "confidential",
    "patent",
    "restricted"
  ]);

  const [suspiciousDests, setSuspiciousDests] = useState<string[]>([
    "usb",
    "media",
    "dropbox",
    "onedrive",
    "googledrive",
    "smb-share",
    "nfs"
  ]);

  // Event handlers
  const handleAddEvent = (newEvt: SFTMSEvent) => {
    setEvents((prev) => [newEvt, ...prev]);
  };

  const handleClearEvents = () => {
    setEvents([]);
  };

  const handleAddSensitiveDir = (dir: string) => {
    if (!sensitiveDirs.includes(dir)) {
      setSensitiveDirs((prev) => [...prev, dir]);
    }
  };

  const handleRemoveSensitiveDir = (dir: string) => {
    setSensitiveDirs((prev) => prev.filter((d) => d !== dir));
  };

  const handleAddSuspiciousDest = (dest: string) => {
    if (!suspiciousDests.includes(dest)) {
      setSuspiciousDests((prev) => [...prev, dest]);
    }
  };

  const handleRemoveSuspiciousDest = (dest: string) => {
    setSuspiciousDests((prev) => prev.filter((d) => d !== dest));
  };

  // Compile full python package sftms-python.zip representation (mock download trigger)
  const handleDownloadPythonZip = () => {
    // Compile a beautiful Readme instructions file inside a text blob representational model
    const readmeContent = `================================================================================
SFTMS - SECURE FILE TRANSFER MONITORING SYSTEM (PYTHON ENGINE)
================================================================================
A Python observer tool designed to watch directories using watchdog, verify
cryptographic integrity, evaluate policies, and write structured JSONL records.

Included source files:
• policy.py   - Policy detection rules & sensitivity evaluations
• hashing.py  - Cryptographic streaming SHA-256 calculators
• monitor.py  - System file watchdog daemon
• report.py   - CLI summary compliance reporter

How to Deploy:
1. Extract ZIP files
2. Run installation:
   pip install watchdog
3. Spin up monitor:
   python monitor.py ~/Documents
4. Compile audit reports:
   python report.py
================================================================================
`;
    const blob = new Blob([readmeContent], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "sftms_python_readme.txt";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-[#050505] text-slate-300 flex flex-col font-sans">
      {/* Top Professional Header Bar */}
      <header className="bg-[#080808] border-b border-white/8 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 bg-sky-500 rounded-lg flex items-center justify-center text-black shadow-[0_0_15px_rgba(56,189,248,0.35)]">
              <Shield className="w-5.5 h-5.5" />
            </div>
            <div>
              <h1 className="text-sm font-bold tracking-tight text-white uppercase">
                Secure File Transfer Monitoring System (SFTMS)
              </h1>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(34,197,94,0.6)] animate-pulse"></span>
                <span className="text-[10px] font-mono text-slate-400 font-medium uppercase tracking-wider">
                  OS Observer Daemon: Active
                </span>
              </div>
            </div>
          </div>

          {/* Quick Header actions */}
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-1.5 text-xs text-slate-400 font-mono bg-white/5 px-2.5 py-1 rounded border border-white/8">
              <Clock className="w-3.5 h-3.5" /> UTC: 2026-06-26
            </div>
            <button 
              onClick={handleDownloadPythonZip}
              className="px-3 py-1.5 bg-sky-500/10 hover:bg-sky-500/20 text-sky-400 font-semibold text-xs rounded-md border border-sky-500/20 flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
              title="Download Python Package Deliverable sftms-python.zip"
            >
              <Download className="w-3.5 h-3.5" /> Download Python Package
            </button>
          </div>
        </div>
      </header>

      {/* Main Container Layout */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
        {/* Navigation Ribbon Selector */}
        <div className="bg-[#0f0f0f] rounded-xl border border-white/8 p-2 flex flex-wrap gap-1 shadow-xs">
          {/* Dashboard Tab */}
          <button
            onClick={() => setActiveTab("dashboard")}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all duration-150 flex items-center gap-1.5 cursor-pointer ${
              activeTab === "dashboard"
                ? "bg-sky-500/10 text-sky-400 border border-sky-500/20 shadow-[0_0_10px_rgba(56,189,248,0.15)]"
                : "text-slate-400 hover:bg-white/5 hover:text-white"
            }`}
            id="tab-dashboard"
          >
            <LayoutDashboard className="w-4 h-4" />
            Dashboard Overview
          </button>

          {/* Logs Tab */}
          <button
            onClick={() => setActiveTab("logs")}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all duration-150 flex items-center gap-1.5 cursor-pointer ${
              activeTab === "logs"
                ? "bg-sky-500/10 text-sky-400 border border-sky-500/20 shadow-[0_0_10px_rgba(56,189,248,0.15)]"
                : "text-slate-400 hover:bg-white/5 hover:text-white"
            }`}
            id="tab-logs"
          >
            <ListCollapse className="w-4 h-4" />
            Audit Logs Ledger ({events.length})
          </button>

          {/* Policy Manager Tab */}
          <button
            onClick={() => setActiveTab("policy")}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all duration-150 flex items-center gap-1.5 cursor-pointer ${
              activeTab === "policy"
                ? "bg-sky-500/10 text-sky-400 border border-sky-500/20 shadow-[0_0_10px_rgba(56,189,248,0.15)]"
                : "text-slate-400 hover:bg-white/5 hover:text-white"
            }`}
            id="tab-policy"
          >
            <Settings className="w-4 h-4" />
            Threat Rules Configuration
          </button>

          {/* Integrity Tab */}
          <button
            onClick={() => setActiveTab("integrity")}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all duration-150 flex items-center gap-1.5 cursor-pointer ${
              activeTab === "integrity"
                ? "bg-sky-500/10 text-sky-400 border border-sky-500/20 shadow-[0_0_10px_rgba(56,189,248,0.15)]"
                : "text-slate-400 hover:bg-white/5 hover:text-white"
            }`}
            id="tab-integrity"
          >
            <FileCheck className="w-4 h-4" />
            Integrity Checker
          </button>

          {/* Audit Report Tab */}
          <button
            onClick={() => setActiveTab("report")}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all duration-150 flex items-center gap-1.5 cursor-pointer ${
              activeTab === "report"
                ? "bg-sky-500/10 text-sky-400 border border-sky-500/20 shadow-[0_0_10px_rgba(56,189,248,0.15)]"
                : "text-slate-400 hover:bg-white/5 hover:text-white"
            }`}
            id="tab-report"
          >
            <FileText className="w-4 h-4" />
            Compliance Audit Report
          </button>

          {/* Python Scripts Tab */}
          <button
            onClick={() => setActiveTab("python")}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all duration-150 flex items-center gap-1.5 cursor-pointer ${
              activeTab === "python"
                ? "bg-sky-500/10 text-sky-400 border border-sky-500/20 shadow-[0_0_10px_rgba(56,189,248,0.15)]"
                : "text-slate-400 hover:bg-white/5 hover:text-white"
            }`}
            id="tab-python"
          >
            <Terminal className="w-4 h-4" />
            Python Monitor Daemon
          </button>
        </div>

        {/* Dynamic Display Area with entrance animations */}
        <div className="outline-hidden" id="tab-content-container">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.2 }}
            >
              {activeTab === "dashboard" && (
                <DashboardOverview 
                  events={events} 
                  onSelectTab={(tab) => setActiveTab(tab)} 
                />
              )}

              {activeTab === "logs" && (
                <LiveLogViewer
                  events={events}
                  onAddEvent={handleAddEvent}
                  onClearEvents={handleClearEvents}
                />
              )}

              {activeTab === "policy" && (
                <PolicyManager
                  sensitiveDirs={sensitiveDirs}
                  suspiciousDests={suspiciousDests}
                  onAddSensitiveDir={handleAddSensitiveDir}
                  onRemoveSensitiveDir={handleRemoveSensitiveDir}
                  onAddSuspiciousDest={handleAddSuspiciousDest}
                  onRemoveSuspiciousDest={handleRemoveSuspiciousDest}
                />
              )}

              {activeTab === "integrity" && (
                <IntegrityCheck />
              )}

              {activeTab === "report" && (
                <AuditReport events={events} />
              )}

              {activeTab === "python" && (
                <PythonScriptsViewer />
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* Footer bar */}
      <footer className="bg-[#080808] border-t border-white/8 mt-auto py-5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 font-mono">
          <p>© 2026 SFTMS Control Panel. Built for Enterprise Data Loss Prevention (DLP).</p>
          <div className="flex items-center gap-4">
            <span>SOC Node: Online</span>
            <span>Version: 2.1.0-Release</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
