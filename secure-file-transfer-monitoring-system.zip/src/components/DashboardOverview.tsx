/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { motion } from "motion/react";
import { 
  ShieldAlert, 
  Database, 
  FileCheck, 
  Activity, 
  AlertTriangle, 
  FileWarning, 
  CheckCircle, 
  FolderLock,
  ArrowRight
} from "lucide-react";
import { SFTMSEvent, AuthorizationStatus, SeverityLevel, IntegrityStatus } from "../types";

interface DashboardOverviewProps {
  events: SFTMSEvent[];
  onSelectTab: (tab: string) => void;
}

export default function DashboardOverview({ events, onSelectTab }: DashboardOverviewProps) {
  // Aggregate calculations
  const totalEvents = events.length;
  
  const unauthorizedEvents = events.filter(
    (e) => e.authorization === AuthorizationStatus.UNAUTHORIZED
  );
  
  const reviewEvents = events.filter(
    (e) => e.authorization === AuthorizationStatus.REVIEW
  );
  
  const integrityMismatches = events.filter(
    (e) => e.integrity === IntegrityStatus.MISMATCH
  );
  
  const sensitiveTouches = events.filter((e) => e.sensitive);

  // SVG Chart: Events by Date (Last 3 days: June 24, 25, 26)
  const june24Count = events.filter((e) => e.timestamp.startsWith("2026-06-24")).length;
  const june25Count = events.filter((e) => e.timestamp.startsWith("2026-06-25")).length;
  const june26Count = events.filter((e) => e.timestamp.startsWith("2026-06-26")).length;

  const maxDailyCount = Math.max(june24Count, june25Count, june26Count, 1);
  const chartPoints = [
    { label: "Jun 24", count: june24Count },
    { label: "Jun 25", count: june25Count },
    { label: "Jun 26 (Today)", count: june26Count },
  ];

  // SVG Chart: Authorization Split
  const authCounts = {
    AUTHORIZED: events.filter((e) => e.authorization === AuthorizationStatus.AUTHORIZED).length,
    REVIEW: events.filter((e) => e.authorization === AuthorizationStatus.REVIEW).length,
    UNAUTHORIZED: events.filter((e) => e.authorization === AuthorizationStatus.UNAUTHORIZED).length,
  };
  const authTotal = totalEvents || 1;
  const authPercentages = {
    AUTHORIZED: Math.round((authCounts.AUTHORIZED / authTotal) * 100),
    REVIEW: Math.round((authCounts.REVIEW / authTotal) * 100),
    UNAUTHORIZED: Math.round((authCounts.UNAUTHORIZED / authTotal) * 100),
  };

  // Severity count
  const severityCounts = {
    LOW: events.filter((e) => e.severity === SeverityLevel.LOW).length,
    MEDIUM: events.filter((e) => e.severity === SeverityLevel.MEDIUM).length,
    HIGH: events.filter((e) => e.severity === SeverityLevel.HIGH).length,
  };

  // Top 5 targeted sensitive files
  const sensitiveFilesFreq: { [key: string]: number } = {};
  events.forEach((e) => {
    if (e.sensitive) {
      // get file name from path
      const parts = e.src.split("/");
      const filename = parts[parts.length - 1] || e.src;
      sensitiveFilesFreq[filename] = (sensitiveFilesFreq[filename] || 0) + 1;
    }
  });
  const topSensitiveFiles = Object.entries(sensitiveFilesFreq)
    .map(([filename, count]) => ({ filename, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  return (
    <div className="space-y-6">
      {/* KPI Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Events */}
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="bg-[#0f0f0f] rounded-xl border border-white/8 p-5 shadow-xs flex items-center justify-between"
          id="stat-total-events"
        >
          <div>
            <p className="text-xs font-mono text-slate-500 uppercase tracking-wider">Total Audited Events</p>
            <h3 className="text-3xl font-bold text-white tracking-tight mt-1">{totalEvents}</h3>
            <p className="text-xs text-slate-400 mt-1 flex items-center gap-1">
              <Activity className="w-3 h-3 text-emerald-400 animate-pulse" /> Live background observer running
            </p>
          </div>
          <div className="w-12 h-12 rounded-lg bg-sky-500/10 flex items-center justify-center text-sky-400 shadow-[0_0_10px_rgba(56,189,248,0.15)]">
            <Database className="w-6 h-6" />
          </div>
        </motion.div>

        {/* Active Alerts */}
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.05 }}
          className="bg-[#0f0f0f] rounded-xl border border-white/8 p-5 shadow-xs flex items-center justify-between border-l-2 border-l-red-500/50"
          id="stat-unauthorized-transfers"
        >
          <div>
            <p className="text-xs font-mono text-slate-500 uppercase tracking-wider">Unauthorized Transfers</p>
            <h3 className="text-3xl font-bold text-red-400 tracking-tight mt-1">{unauthorizedEvents.length}</h3>
            <p className="text-xs text-slate-400 mt-1">
              Blocked or policy-violating exfiltrations
            </p>
          </div>
          <div className="w-12 h-12 rounded-lg bg-red-500/10 flex items-center justify-center text-red-400 shadow-[0_0_10px_rgba(239,68,68,0.15)]">
            <ShieldAlert className="w-6 h-6" />
          </div>
        </motion.div>

        {/* Pending Security Reviews */}
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1 }}
          className="bg-[#0f0f0f] rounded-xl border border-white/8 p-5 shadow-xs flex items-center justify-between"
          id="stat-pending-reviews"
        >
          <div>
            <p className="text-xs font-mono text-slate-500 uppercase tracking-wider">Threat Reviews</p>
            <h3 className="text-3xl font-bold text-amber-400 tracking-tight mt-1">{reviewEvents.length}</h3>
            <p className="text-xs text-slate-400 mt-1">
              Suspicious activity on sensitive logs
            </p>
          </div>
          <div className="w-12 h-12 rounded-lg bg-amber-500/10 flex items-center justify-center text-amber-400 shadow-[0_0_10px_rgba(245,158,11,0.15)]">
            <AlertTriangle className="w-6 h-6" />
          </div>
        </motion.div>

        {/* Integrity Mismatches */}
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.15 }}
          className="bg-[#0f0f0f] rounded-xl border border-white/8 p-5 shadow-xs flex items-center justify-between"
          id="stat-integrity-failures"
        >
          <div>
            <p className="text-xs font-mono text-slate-500 uppercase tracking-wider">Integrity Mismatches</p>
            <h3 className="text-3xl font-bold text-rose-400 tracking-tight mt-1">{integrityMismatches.length}</h3>
            <p className="text-xs text-slate-400 mt-1">
              Framer-level file tampering alerts
            </p>
          </div>
          <div className="w-12 h-12 rounded-lg bg-rose-500/10 flex items-center justify-center text-rose-400 shadow-[0_0_10px_rgba(244,63,94,0.15)]">
            <FileWarning className="w-6 h-6" />
          </div>
        </motion.div>
      </div>

      {/* Main Charts & Indicators Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Interactive Timeline & Distribution */}
        <div className="lg:col-span-2 space-y-6">
          {/* File Transfer Activity Over Time */}
          <div className="bg-[#0f0f0f] rounded-xl border border-white/8 p-6" id="card-activity-trend">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-semibold text-white">File Transfer Timeline</h3>
                <p className="text-xs text-slate-400">Chronological distribution of intercepted system events</p>
              </div>
              <span className="text-[10px] font-mono bg-sky-500/10 text-sky-400 border border-sky-500/20 px-2 py-0.5 rounded-full uppercase">
                Hourly Watch
              </span>
            </div>

            {/* Custom SVG Line & Bar Chart Combo */}
            <div className="h-48 w-full flex items-end justify-between px-4 pb-2 border-b border-white/8 relative pt-8">
              {/* Grid Lines */}
              <div className="absolute inset-0 flex flex-col justify-between pointer-events-none py-2 text-[9px] text-slate-700 font-mono">
                <div className="border-b border-dashed border-white/5 w-full pt-2"></div>
                <div className="border-b border-dashed border-white/5 w-full"></div>
                <div className="border-b border-dashed border-white/5 w-full"></div>
              </div>

              {chartPoints.map((pt, idx) => {
                const heightPercent = (pt.count / maxDailyCount) * 80 + 10;
                return (
                  <div key={idx} className="flex flex-col items-center flex-1 group z-10">
                    {/* Event Count tooltip on hover */}
                    <div className="mb-2 bg-[#151515] text-sky-400 border border-white/8 text-[10px] font-mono px-2 py-0.5 rounded shadow-sm opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                      {pt.count} events
                    </div>
                    {/* Bar */}
                    <div className="w-16 bg-gradient-to-t from-sky-500 to-sky-400 rounded-t-md hover:from-sky-400 hover:to-sky-300 transition-all duration-300 shadow-[0_0_15px_rgba(56,189,248,0.15)] relative" style={{ height: `${heightPercent}%` }}>
                      <div className="absolute -top-6 left-0 right-0 text-center text-xs font-bold text-sky-400">
                        {pt.count}
                      </div>
                    </div>
                    {/* Label */}
                    <span className="text-xs text-slate-400 mt-2 font-medium">{pt.label}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Lower Grid: Split Statistics */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Split A: Threat Authorization Ring Chart */}
            <div className="bg-[#0f0f0f] rounded-xl border border-white/8 p-6" id="card-auth-split">
              <h3 className="text-sm font-semibold text-white mb-3">Policy Audit Split</h3>
              <div className="flex items-center justify-between">
                {/* SVG Ring Donut Chart */}
                <div className="relative w-28 h-28">
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                    {/* Background Circle */}
                    <circle cx="18" cy="18" r="15.915" fill="none" stroke="#1f1f1f" strokeWidth="3" />
                    
                    {/* Authorized segment */}
                    <circle 
                      cx="18" cy="18" r="15.915" fill="none" 
                      stroke="#10b981" strokeWidth="3" 
                      strokeDasharray={`${authPercentages.AUTHORIZED} ${100 - authPercentages.AUTHORIZED}`}
                      strokeDashoffset="0"
                    />
                    
                    {/* Review segment */}
                    <circle 
                      cx="18" cy="18" r="15.915" fill="none" 
                      stroke="#f59e0b" strokeWidth="3" 
                      strokeDasharray={`${authPercentages.REVIEW} ${100 - authPercentages.REVIEW}`}
                      strokeDashoffset={-authPercentages.AUTHORIZED}
                    />

                    {/* Unauthorized segment */}
                    <circle 
                      cx="18" cy="18" r="15.915" fill="none" 
                      stroke="#ef4444" strokeWidth="3" 
                      strokeDasharray={`${authPercentages.UNAUTHORIZED} ${100 - authPercentages.UNAUTHORIZED}`}
                      strokeDashoffset={-(authPercentages.AUTHORIZED + authPercentages.REVIEW)}
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                    <span className="text-lg font-bold text-white">{authPercentages.UNAUTHORIZED}%</span>
                    <span className="text-[9px] font-mono text-slate-400 uppercase">Violations</span>
                  </div>
                </div>

                {/* Legend list */}
                <div className="space-y-2 flex-1 pl-4">
                  <div className="flex items-center justify-between text-xs">
                    <span className="flex items-center gap-1.5 text-slate-300">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.4)]"></span> Authorized
                    </span>
                    <span className="font-mono text-slate-400 font-medium">{authCounts.AUTHORIZED}</span>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="flex items-center gap-1.5 text-slate-300">
                      <span className="w-2.5 h-2.5 rounded-full bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.4)]"></span> Policy Review
                    </span>
                    <span className="font-mono text-slate-400 font-medium">{authCounts.REVIEW}</span>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="flex items-center gap-1.5 text-slate-300">
                      <span className="w-2.5 h-2.5 rounded-full bg-red-500 shadow-[0_0_8px_rgba(239,108,108,0.4)]"></span> Unauthorized
                    </span>
                    <span className="font-mono text-slate-400 font-medium">{authCounts.UNAUTHORIZED}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Split B: Severity breakdown */}
            <div className="bg-[#0f0f0f] rounded-xl border border-white/8 p-6" id="card-severity-breakdown">
              <h3 className="text-sm font-semibold text-white mb-3">Severity Allocation</h3>
              <div className="space-y-3">
                {/* High Severity */}
                <div>
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="font-medium text-red-400">HIGH SEVERITY</span>
                    <span className="font-mono text-slate-400 font-semibold">{severityCounts.HIGH}</span>
                  </div>
                  <div className="w-full bg-white/5 h-2 rounded-full overflow-hidden">
                    <div className="bg-red-500 h-full rounded-full shadow-[0_0_8px_rgba(239,68,68,0.5)]" style={{ width: `${(severityCounts.HIGH / totalEvents) * 100}%` }}></div>
                  </div>
                </div>

                {/* Medium Severity */}
                <div>
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="font-medium text-amber-400">MEDIUM SEVERITY</span>
                    <span className="font-mono text-slate-400 font-semibold">{severityCounts.MEDIUM}</span>
                  </div>
                  <div className="w-full bg-white/5 h-2 rounded-full overflow-hidden">
                    <div className="bg-amber-500 h-full rounded-full shadow-[0_0_8px_rgba(245,158,11,0.5)]" style={{ width: `${(severityCounts.MEDIUM / totalEvents) * 100}%` }}></div>
                  </div>
                </div>

                {/* Low Severity */}
                <div>
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="font-medium text-emerald-400 font-semibold">LOW SEVERITY</span>
                    <span className="font-mono text-slate-400 font-semibold">{severityCounts.LOW}</span>
                  </div>
                  <div className="w-full bg-white/5 h-2 rounded-full overflow-hidden">
                    <div className="bg-emerald-500 h-full rounded-full shadow-[0_0_8px_rgba(16,185,129,0.5)]" style={{ width: `${(severityCounts.LOW / totalEvents) * 100}%` }}></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Panel: Alerts & Restricted File Tracking */}
        <div className="space-y-6">
          {/* Threat Meter Indicator */}
          <div className="bg-[#0f0f0f] rounded-xl border border-white/8 p-5 shadow-xs" id="card-threat-level">
            <h3 className="text-xs font-mono text-slate-500 uppercase tracking-wider mb-2">Overall Risk Level</h3>
            <div className="flex items-end justify-between">
              <div>
                <h4 className={`text-2xl font-bold ${
                  unauthorizedEvents.length > 5 ? "text-red-400" : unauthorizedEvents.length > 0 ? "text-amber-400" : "text-emerald-400"
                }`}>
                  {unauthorizedEvents.length > 5 ? "CRITICAL RISK" : unauthorizedEvents.length > 0 ? "ELEVATED RISK" : "SECURE"}
                </h4>
                <p className="text-xs text-slate-400 mt-1">
                  Based on active USB/Cloud policy violations
                </p>
              </div>
              <div className="text-right">
                <span className="text-2xl font-mono font-bold text-white">
                  {unauthorizedEvents.length * 10 + reviewEvents.length * 2 > 100 
                    ? "100" 
                    : unauthorizedEvents.length * 10 + reviewEvents.length * 2}
                </span>
                <span className="text-xs font-mono text-slate-500">/100</span>
              </div>
            </div>
            {/* Progress/risk bar */}
            <div className="w-full bg-white/5 h-2.5 rounded-full mt-3 overflow-hidden">
              <div 
                className={`h-full rounded-full transition-all duration-500 ${
                  unauthorizedEvents.length > 5 ? "bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.5)]" : unauthorizedEvents.length > 0 ? "bg-amber-400 shadow-[0_0_10px_rgba(245,158,11,0.5)]" : "bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]"
                }`} 
                style={{ width: `${Math.min((unauthorizedEvents.length * 10 + reviewEvents.length * 2), 100)}%` }}
              ></div>
            </div>
          </div>

          {/* Top Sensitive Files Touched */}
          <div className="bg-[#0f0f0f] rounded-xl border border-white/8 p-5 shadow-xs" id="card-top-sensitive">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-white flex items-center gap-1.5">
                <FolderLock className="w-4 h-4 text-sky-400" /> Top Sensitive Files
              </h3>
              <span className="text-[10px] font-mono bg-white/5 text-slate-400 px-2 py-0.5 rounded-full border border-white/5">
                {sensitiveTouches.length} Total Touches
              </span>
            </div>

            {topSensitiveFiles.length === 0 ? (
              <p className="text-xs text-slate-500 text-center py-4">No restricted files have been touched.</p>
            ) : (
              <div className="space-y-3">
                {topSensitiveFiles.map((item, idx) => (
                  <div key={idx} className="flex items-center justify-between text-xs border-b border-white/5 pb-2 last:border-0 last:pb-0">
                    <div className="truncate max-w-[180px]">
                      <span className="font-mono text-slate-300 font-medium block truncate">{item.filename}</span>
                      <span className="text-[10px] text-slate-500 block">Classified in SENSITIVE_DIRS</span>
                    </div>
                    <span className="font-mono text-red-400 bg-red-500/10 border border-red-500/20 font-bold px-2 py-0.5 rounded">
                      {item.count} events
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Critical Incident Alert Center */}
          <div className="bg-[#0f0f0f] rounded-xl border border-white/8 p-5 shadow-xs" id="card-active-incidents">
            <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-1.5">
              <ShieldAlert className="w-4 h-4 text-red-400 animate-pulse" /> Critical Incidents (Recent)
            </h3>
            
            {unauthorizedEvents.length === 0 ? (
              <div className="text-center py-6 border border-dashed border-white/8 rounded-lg">
                <CheckCircle className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
                <p className="text-xs text-slate-300 font-medium">Compliance guidelines fully satisfied!</p>
                <p className="text-[10px] text-slate-500">0 unauthorized events recorded.</p>
              </div>
            ) : (
              <div className="space-y-3 max-h-[190px] overflow-y-auto pr-1">
                {unauthorizedEvents.slice(0, 3).map((alert) => (
                  <div 
                    key={alert.id} 
                    className="p-3 bg-red-500/5 border border-red-500/10 rounded-lg space-y-1.5 relative hover:bg-red-500/10 transition-colors duration-200"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono font-bold text-red-400 bg-red-500/20 px-1.5 py-0.5 rounded uppercase">
                        {alert.event}
                      </span>
                      <span className="text-[9px] font-mono text-slate-500">
                        {new Date(alert.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    <p className="text-xs font-mono text-slate-300 font-medium break-all block">
                      {alert.src.split("/").pop()}
                    </p>
                    {alert.dest && (
                      <p className="text-[10px] text-slate-400 truncate block">
                        → {alert.dest}
                      </p>
                    )}
                    <p className="text-[10px] text-slate-500 italic block line-clamp-2">
                      {alert.details}
                    </p>
                  </div>
                ))}

                {unauthorizedEvents.length > 3 && (
                  <button 
                    onClick={() => onSelectTab("logs")}
                    className="w-full py-1.5 text-center text-xs font-medium text-sky-400 hover:text-sky-300 flex items-center justify-center gap-1 mt-1 border border-sky-500/20 rounded-md bg-sky-500/10"
                  >
                    View all {unauthorizedEvents.length} violations <ArrowRight className="w-3 h-3" />
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
