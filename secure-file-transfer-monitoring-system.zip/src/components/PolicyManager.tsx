/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, FormEvent } from "react";
import { motion } from "motion/react";
import { 
  FolderLock, 
  MapPin, 
  Plus, 
  Trash2, 
  HelpCircle, 
  ShieldAlert, 
  ShieldCheck, 
  AlertCircle,
  Play
} from "lucide-react";
import { EventType, AuthorizationStatus, SeverityLevel } from "../types";

interface PolicyManagerProps {
  sensitiveDirs: string[];
  suspiciousDests: string[];
  onAddSensitiveDir: (dir: string) => void;
  onRemoveSensitiveDir: (dir: string) => void;
  onAddSuspiciousDest: (dest: string) => void;
  onRemoveSuspiciousDest: (dest: string) => void;
}

export default function PolicyManager({
  sensitiveDirs,
  suspiciousDests,
  onAddSensitiveDir,
  onRemoveSensitiveDir,
  onAddSuspiciousDest,
  onRemoveSuspiciousDest
}: PolicyManagerProps) {
  // Input fields state
  const [newDir, setNewDir] = useState("");
  const [newDest, setNewDest] = useState("");

  // Tester playground state
  const [testSrc, setTestSrc] = useState("/Users/admin/Confidential/Patent_Summary.pdf");
  const [testDest, setTestDest] = useState("/media/usb0/Patent_Summary.pdf");
  const [testEvent, setTestEvent] = useState<EventType>(EventType.MOVED);

  // Run mock evaluation on test inputs
  const evaluateTestPath = () => {
    const srcLower = testSrc.toLowerCase();
    const destLower = testDest.toLowerCase();

    const isSensitive = sensitiveDirs.some(dir => srcLower.includes(dir.toLowerCase()));
    const isSuspicious = testDest ? suspiciousDests.some(d => destLower.includes(d.toLowerCase())) : false;

    let auth = AuthorizationStatus.AUTHORIZED;
    let severity = SeverityLevel.LOW;
    let desc = "Standard Routine Activity. No policy violations detected.";

    if (isSensitive) {
      if (testEvent === EventType.DELETED) {
        auth = AuthorizationStatus.UNAUTHORIZED;
        severity = SeverityLevel.HIGH;
        desc = "CRITICAL VIOLATION: Destruction of restricted/sensitive resources without approval token.";
      } else if (testEvent === EventType.MOVED && isSuspicious) {
        auth = AuthorizationStatus.UNAUTHORIZED;
        severity = SeverityLevel.HIGH;
        desc = "CRITICAL VIOLATION: Exfiltration of a protected file to an unauthorized destination channel (USB/Cloud Sync).";
      } else if (testEvent === EventType.MOVED) {
        auth = AuthorizationStatus.REVIEW;
        severity = SeverityLevel.MEDIUM;
        desc = "SUSPICIOUS MOVEMENT: Sensitive file moved inside internal file hierarchy. Security team review suggested.";
      } else {
        auth = AuthorizationStatus.REVIEW;
        severity = SeverityLevel.MEDIUM;
        desc = "SUSPICIOUS ACTIVITY: Sensitive file created or modified in restricted zone.";
      }
    } else if (isSuspicious) {
      auth = AuthorizationStatus.REVIEW;
      severity = SeverityLevel.LOW;
      desc = "INFORMATIONAL NOTICE: Normal asset transferred to suspicious destination channels.";
    }

    return { isSensitive, isSuspicious, auth, severity, desc };
  };

  const testResult = evaluateTestPath();

  const handleAddDir = (e: FormEvent) => {
    e.preventDefault();
    if (newDir.trim()) {
      onAddSensitiveDir(newDir.trim());
      setNewDir("");
    }
  };

  const handleAddDest = (e: FormEvent) => {
    e.preventDefault();
    if (newDest.trim()) {
      onAddSuspiciousDest(newDest.trim());
      setNewDest("");
    }
  };

  return (
    <div className="space-y-6">
      {/* Intro info */}
      <div className="bg-[#0f0f0f] rounded-xl border border-white/8 p-5 shadow-xs">
        <h3 className="text-sm font-semibold text-white">Threat Matrix & Rules Manager</h3>
        <p className="text-xs text-slate-500 mt-0.5">
          SFTMS detects threats by checking if filesystem actions cross sensitive paths (source directories) into untrusted external folders (destinations). Configure directory signatures below.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Col: Rules Lists */}
        <div className="space-y-6">
          {/* Sensitive Folders Rule Board */}
          <div className="bg-[#0f0f0f] rounded-xl border border-white/8 p-5 shadow-xs" id="policy-sensitive-dirs">
            <div className="flex items-center gap-1.5 text-white font-semibold text-xs mb-3">
              <FolderLock className="w-4.5 h-4.5 text-red-400" />
              <span>SENSITIVE_DIRS Configuration</span>
            </div>
            <p className="text-xs text-slate-500 mb-4">
              Events matching these substrings will trigger immediate tracking audits or block restrictions if moved.
            </p>

            {/* Quick add form */}
            <form onSubmit={handleAddDir} className="flex gap-2 mb-4">
              <input 
                type="text"
                placeholder="e.g., /etc/shadow, /var/secure, payroll"
                className="bg-white/5 border border-white/8 rounded px-2.5 py-1.5 text-xs text-white placeholder:text-slate-500 focus:outline-none flex-1"
                value={newDir}
                onChange={(e) => setNewDir(e.target.value)}
              />
              <button 
                type="submit" 
                className="bg-sky-500 hover:bg-sky-400 text-black font-semibold text-xs px-3 py-1.5 rounded flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" /> Add
              </button>
            </form>

            {/* Active directory list */}
            <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
              {sensitiveDirs.length === 0 ? (
                <div className="text-center py-4 text-xs text-slate-600">No sensitive directories configured</div>
              ) : (
                sensitiveDirs.map((dir, idx) => (
                  <div key={idx} className="flex items-center justify-between text-xs bg-white/2 border border-white/5 px-3 py-2 rounded">
                    <span className="font-mono text-slate-300 font-semibold">{dir}</span>
                    <button 
                      onClick={() => onRemoveSensitiveDir(dir)}
                      className="text-slate-500 hover:text-red-400 transition-colors duration-150 p-0.5 cursor-pointer"
                      title="Remove Rule Pattern"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Suspicious Destinations Rule Board */}
          <div className="bg-[#0f0f0f] rounded-xl border border-white/8 p-5 shadow-xs" id="policy-suspicious-dests">
            <div className="flex items-center gap-1.5 text-white font-semibold text-xs mb-3">
              <MapPin className="w-4.5 h-4.5 text-sky-400" />
              <span>SUSPICIOUS_DESTINATIONS Configuration</span>
            </div>
            <p className="text-xs text-slate-500 mb-4">
              Destination paths matching these patterns trigger critical data-loss-prevention (DLP) alerts.
            </p>

            {/* Quick add form */}
            <form onSubmit={handleAddDest} className="flex gap-2 mb-4">
              <input 
                type="text"
                placeholder="e.g., dropbox, onedrive, backup_share"
                className="bg-white/5 border border-white/8 rounded px-2.5 py-1.5 text-xs text-white placeholder:text-slate-500 focus:outline-none flex-1"
                value={newDest}
                onChange={(e) => setNewDest(e.target.value)}
              />
              <button 
                type="submit" 
                className="bg-sky-500 hover:bg-sky-400 text-black font-semibold text-xs px-3 py-1.5 rounded flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" /> Add
              </button>
            </form>

            {/* Active list */}
            <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
              {suspiciousDests.length === 0 ? (
                <div className="text-center py-4 text-xs text-slate-600">No suspicious destinations configured</div>
              ) : (
                suspiciousDests.map((dest, idx) => (
                  <div key={idx} className="flex items-center justify-between text-xs bg-white/2 border border-white/5 px-3 py-2 rounded">
                    <span className="font-mono text-slate-300 font-semibold">{dest}</span>
                    <button 
                      onClick={() => onRemoveSuspiciousDest(dest)}
                      className="text-slate-500 hover:text-red-400 transition-colors duration-150 p-0.5 cursor-pointer"
                      title="Remove Rule Pattern"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Right Col: Active Rule Sandbox Tester */}
        <div className="space-y-6">
          <div className="bg-[#0f0f0f] rounded-xl border border-white/8 p-5 shadow-xs" id="policy-sandbox-playground">
            <h3 className="text-sm font-semibold text-white flex items-center gap-1.5">
              <Play className="w-4 h-4 text-sky-400 animate-pulse" /> Policy Sandbox Playground
            </h3>
            <p className="text-xs text-slate-500 mt-0.5 mb-4">
              Input hypothetical filesystem paths to test how the current active ruleset classifies the transaction.
            </p>

            <div className="space-y-4 text-xs">
              {/* Event Type */}
              <div>
                <label className="block text-slate-400 font-bold uppercase text-[10px] mb-1">Simulated File Action</label>
                <select 
                  className="w-full bg-white/5 border border-white/8 rounded px-3 py-2 text-xs text-white focus:outline-none"
                  value={testEvent}
                  onChange={(e) => setTestEvent(e.target.value as EventType)}
                >
                  <option value={EventType.CREATED} className="bg-[#151515] text-white">CREATED</option>
                  <option value={EventType.MODIFIED} className="bg-[#151515] text-white">MODIFIED</option>
                  <option value={EventType.MOVED} className="bg-[#151515] text-white">MOVED (Requires Destination)</option>
                  <option value={EventType.DELETED} className="bg-[#151515] text-white">DELETED</option>
                </select>
              </div>

              {/* Source Path */}
              <div>
                <label className="block text-slate-400 font-bold uppercase text-[10px] mb-1">Source File Path</label>
                <input 
                  type="text" 
                  className="w-full bg-white/5 border border-white/8 rounded px-3 py-2 font-mono text-xs text-white focus:outline-none"
                  value={testSrc}
                  onChange={(e) => setTestSrc(e.target.value)}
                  placeholder="/Users/research/Confidential/Formula_v2.docx"
                />
              </div>

              {/* Destination Path */}
              {testEvent === EventType.MOVED && (
                <div>
                  <label className="block text-slate-400 font-bold uppercase text-[10px] mb-1">Destination File Path</label>
                  <input 
                    type="text" 
                    className="w-full bg-white/5 border border-white/8 rounded px-3 py-2 font-mono text-xs text-white focus:outline-none"
                    value={testDest}
                    onChange={(e) => setTestDest(e.target.value)}
                    placeholder="/media/usb0/Formula_v2.docx"
                  />
                </div>
              )}

              {/* Classification Result Card */}
              <div className="border-t border-white/8 pt-4 mt-4 space-y-3">
                <h4 className="font-bold text-white">Audit Classification Result</h4>

                <div className="grid grid-cols-2 gap-3 text-center">
                  <div className={`p-2.5 rounded border text-xs ${
                    testResult.isSensitive ? "bg-red-500/10 border-red-500/20 text-red-400" : "bg-emerald-500/10 border-emerald-500/20 text-emerald-400"
                  }`}>
                    <span className="block font-semibold text-[10px] uppercase">Is Resource Sensitive?</span>
                    <span className="font-bold text-sm mt-0.5 block">{testResult.isSensitive ? "YES 🔴" : "NO 🟢"}</span>
                  </div>
                  <div className={`p-2.5 rounded border text-xs ${
                    testResult.isSuspicious ? "bg-amber-500/10 border-amber-500/20 text-amber-400" : "bg-emerald-500/10 border-emerald-500/20 text-emerald-400"
                  }`}>
                    <span className="block font-semibold text-[10px] uppercase">Suspicious Destination?</span>
                    <span className="font-bold text-sm mt-0.5 block">{testResult.isSuspicious ? "YES ⚠️" : "NO 🟢"}</span>
                  </div>
                </div>

                {/* Primary Evaluation Status */}
                <div className={`p-4 rounded-lg border flex items-start gap-3 ${
                  testResult.auth === AuthorizationStatus.UNAUTHORIZED ? "bg-red-500/10 border-red-500/20 text-red-400" :
                  testResult.auth === AuthorizationStatus.REVIEW ? "bg-amber-500/10 border-amber-500/20 text-amber-400" :
                  "bg-emerald-500/10 border-emerald-500/20 text-emerald-400"
                }`}>
                  {testResult.auth === AuthorizationStatus.UNAUTHORIZED ? (
                    <ShieldAlert className="w-5 h-5 shrink-0 mt-0.5 text-red-400 animate-bounce" />
                  ) : testResult.auth === AuthorizationStatus.REVIEW ? (
                    <AlertCircle className="w-5 h-5 shrink-0 mt-0.5 text-amber-400" />
                  ) : (
                    <ShieldCheck className="w-5 h-5 shrink-0 mt-0.5 text-emerald-400" />
                  )}

                  <div className="space-y-1">
                    <span className="block font-bold uppercase tracking-wider text-xs">
                      RULE DISPOSITION: {testResult.auth}
                    </span>
                    <span className="block font-mono font-bold text-[10px] uppercase">
                      Severity: {testResult.severity}
                    </span>
                    <p className="text-xs text-slate-300 italic font-medium leading-relaxed block mt-1.5">
                      "{testResult.desc}"
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
