/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useMemo, FormEvent } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Search, 
  SlidersHorizontal, 
  Trash2, 
  ExternalLink, 
  CheckCircle, 
  AlertTriangle, 
  XCircle, 
  CornerDownRight, 
  RefreshCw, 
  ShieldAlert, 
  Plus, 
  Database,
  User,
  Cpu,
  Fingerprint,
  Info,
  Calendar,
  Layers
} from "lucide-react";
import { SFTMSEvent, EventType, IntegrityStatus, AuthorizationStatus, SeverityLevel } from "../types";

interface LiveLogViewerProps {
  events: SFTMSEvent[];
  onAddEvent: (event: SFTMSEvent) => void;
  onClearEvents: () => void;
}

export default function LiveLogViewer({ events, onAddEvent, onClearEvents }: LiveLogViewerProps) {
  // Filters state
  const [searchTerm, setSearchTerm] = useState("");
  const [filterSeverity, setFilterSeverity] = useState<string>("ALL");
  const [filterAuth, setFilterAuth] = useState<string>("ALL");
  const [filterIntegrity, setFilterIntegrity] = useState<string>("ALL");
  const [filterSensitivity, setFilterSensitivity] = useState<string>("ALL");

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  // Modal event state
  const [selectedEvent, setSelectedEvent] = useState<SFTMSEvent | null>(null);

  // Custom simulation panel state
  const [showSimPanel, setShowSimPanel] = useState(false);
  const [simEvent, setSimEvent] = useState({
    event: EventType.MOVED,
    src: "/Users/finance/Confidential/Q2_M&A_Details.xlsx",
    dest: "/media/usb0/Q2_M&A_Details.xlsx",
    user: "mcollins",
    host: "WS-FIN-021",
    process: "explorer.exe",
    hash_before: "b83a2176d18bc9fa8e718bc32107ffcb92d711a8b277d339d2c12a4f61e8c9d2",
    hash_after: "b83a2176d18bc9fa8e718bc32107ffcb92d711a8b277d339d2c12a4f61e8c9d2",
    details: "Unauthorised copy of mergers and acquisitions spreadsheet to USB storage."
  });

  // Reset pagination on filter change
  const resetPage = () => setCurrentPage(1);

  // Filtered Events
  const filteredEvents = useMemo(() => {
    return events.filter((e) => {
      // Search
      const textToSearch = `${e.src} ${e.dest || ""} ${e.user} ${e.host} ${e.process}`.toLowerCase();
      const matchesSearch = textToSearch.includes(searchTerm.toLowerCase());

      // Severity
      const matchesSeverity = filterSeverity === "ALL" || e.severity === filterSeverity;

      // Auth
      const matchesAuth = filterAuth === "ALL" || e.authorization === filterAuth;

      // Integrity
      const matchesIntegrity = filterIntegrity === "ALL" || e.integrity === filterIntegrity;

      // Sensitivity
      const matchesSensitivity = 
        filterSensitivity === "ALL" || 
        (filterSensitivity === "SENSITIVE" && e.sensitive) ||
        (filterSensitivity === "NORMAL" && !e.sensitive);

      return matchesSearch && matchesSeverity && matchesAuth && matchesIntegrity && matchesSensitivity;
    });
  }, [events, searchTerm, filterSeverity, filterAuth, filterIntegrity, filterSensitivity]);

  // Paginated Events
  const paginatedEvents = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredEvents.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredEvents, currentPage, itemsPerPage]);

  const totalPages = Math.ceil(filteredEvents.length / itemsPerPage) || 1;

  // Presets for quick simulation triggering
  const triggerPresetSimulation = (presetType: string) => {
    const timestamp = new Date().toISOString();
    let newEvt: SFTMSEvent;

    switch (presetType) {
      case "USB_EXFIL":
        newEvt = {
          id: `evt-sim-${Date.now()}`,
          timestamp,
          event: EventType.MOVED,
          src: "/Users/admin/Confidential/Q3_Strategic_Patent.pdf",
          dest: "/media/usb1/Q3_Strategic_Patent.pdf",
          user: "jsmith",
          host: "WS-ENG-902",
          pid: 14502,
          process: "cmd.exe",
          hash_before: "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
          hash_after: "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
          integrity: IntegrityStatus.MATCH,
          sensitive: true,
          suspicious_destination: true,
          authorization: AuthorizationStatus.UNAUTHORIZED,
          severity: SeverityLevel.HIGH,
          details: "ALERT: Confidential patent movement identified pointing directly to untrusted removable media (/media/usb1)."
        };
        break;

      case "MALWARE_TAMPER":
        newEvt = {
          id: `evt-sim-${Date.now()}`,
          timestamp,
          event: EventType.MODIFIED,
          src: "/etc/pam.d/common-session",
          user: "www-data",
          host: "SRV-WEB-01",
          pid: 9942,
          process: "curl",
          hash_before: "fc4a2b6e8d1c0b9a8f7e6d5c4b3a2f1e0d9c8b7a6f5e4d3c2b1a0f9e8d7c6b5a",
          hash_after: "90da12e4f5a3b2c1d0e9f8a7b6c5d4e3f2a1b0c9d8e7f6a5b4c3d2e1f0a9b8c7",
          integrity: IntegrityStatus.MISMATCH,
          sensitive: true,
          suspicious_destination: false,
          authorization: AuthorizationStatus.UNAUTHORIZED,
          severity: SeverityLevel.HIGH,
          details: "ALERT: System shell-authentication PAM module modified dynamically by web process curl. Signature mismatch detected!"
        };
        break;

      case "ROUTINE_BUILD":
        newEvt = {
          id: `evt-sim-${Date.now()}`,
          timestamp,
          event: EventType.CREATED,
          src: "/Users/developer/projects/app/dist/assets/index-38fd2.js",
          user: "developer",
          host: "WS-DEV-001",
          pid: 2409,
          process: "vite",
          hash_before: "",
          hash_after: "6e2d1c0b9a8f7e6d5c4b3a2f1e0d9c8b7a6f5e4d3c2b1a0f9e8d7c6b5a4f3e2d",
          integrity: IntegrityStatus.MATCH,
          sensitive: false,
          suspicious_destination: false,
          authorization: AuthorizationStatus.AUTHORIZED,
          severity: SeverityLevel.LOW,
          details: "Vite build compiler emitted production asset. Valid routine write event."
        };
        break;

      default:
        return;
    }

    onAddEvent(newEvt);
    setSelectedEvent(newEvt); // auto highlight details
  };

  // Trigger Custom Form Simulation
  const handleCustomSimulationSubmit = (e: FormEvent) => {
    e.preventDefault();
    const timestamp = new Date().toISOString();
    
    // Auto calculate sensitivity and authorization based on mock Policy Rules
    const isSensitive = simEvent.src.toLowerCase().includes("confidential") || 
                        simEvent.src.toLowerCase().includes("patent") || 
                        simEvent.src.toLowerCase().includes("/etc/") || 
                        simEvent.src.toLowerCase().includes("restricted");

    const isSuspicious = !!simEvent.dest && (
      simEvent.dest.toLowerCase().includes("usb") ||
      simEvent.dest.toLowerCase().includes("media") ||
      simEvent.dest.toLowerCase().includes("dropbox") ||
      simEvent.dest.toLowerCase().includes("onedrive") ||
      simEvent.dest.toLowerCase().includes("googledrive")
    );

    let auth = AuthorizationStatus.AUTHORIZED;
    let severity = SeverityLevel.LOW;
    
    if (isSensitive) {
      if (simEvent.event === EventType.DELETED) {
        auth = AuthorizationStatus.UNAUTHORIZED;
        severity = SeverityLevel.HIGH;
      } else if (simEvent.event === EventType.MOVED && isSuspicious) {
        auth = AuthorizationStatus.UNAUTHORIZED;
        severity = SeverityLevel.HIGH;
      } else {
        auth = AuthorizationStatus.REVIEW;
        severity = SeverityLevel.MEDIUM;
      }
    } else if (isSuspicious) {
      auth = AuthorizationStatus.REVIEW;
      severity = SeverityLevel.LOW;
    }

    // Hash comparison integrity
    let integrity = IntegrityStatus.MATCH;
    if (simEvent.event === EventType.DELETED) {
      integrity = IntegrityStatus.NA;
    } else if (simEvent.hash_before && simEvent.hash_after && simEvent.hash_before !== simEvent.hash_after) {
      integrity = IntegrityStatus.MISMATCH;
      if (isSensitive) {
        auth = AuthorizationStatus.UNAUTHORIZED;
        severity = SeverityLevel.HIGH;
      }
    }

    const newEvt: SFTMSEvent = {
      id: `evt-sim-${Date.now()}`,
      timestamp,
      event: simEvent.event,
      src: simEvent.src,
      dest: simEvent.dest || undefined,
      user: simEvent.user,
      host: simEvent.host,
      pid: Math.floor(Math.random() * 25000) + 1000,
      process: simEvent.process,
      hash_before: simEvent.event === EventType.CREATED ? "" : simEvent.hash_before,
      hash_after: simEvent.event === EventType.DELETED ? "" : simEvent.hash_after,
      integrity,
      sensitive: isSensitive,
      suspicious_destination: isSuspicious,
      authorization: auth,
      severity,
      details: simEvent.details || `Simulated custom ${simEvent.event} event.`
    };

    onAddEvent(newEvt);
    setSelectedEvent(newEvt); // show audit details modal
    setShowSimPanel(false); // hide sim tab
  };

  return (
    <div className="space-y-6">
      {/* Simulation Bar */}
      <div className="bg-[#0f0f0f] text-white rounded-xl border border-white/8 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h3 className="text-sm font-semibold tracking-wide flex items-center gap-1.5 text-sky-400 uppercase">
            <Cpu className="w-4 h-4 text-sky-400" /> SFTMS Threat Simulator
          </h3>
          <p className="text-xs text-slate-400 mt-0.5 font-sans">Inject preconfigured mock compliance breaches or generate custom file actions to stress-test your rules.</p>
        </div>

        <div className="flex flex-wrap gap-2">
          <button 
            onClick={() => triggerPresetSimulation("USB_EXFIL")}
            className="px-3 py-1.5 text-xs font-semibold bg-red-500/10 border border-red-500/20 text-red-400 hover:bg-red-500/20 rounded-md transition-all duration-150 flex items-center gap-1 cursor-pointer"
          >
            <ShieldAlert className="w-3.5 h-3.5" /> Exfiltrate Patents to USB
          </button>
          <button 
            onClick={() => triggerPresetSimulation("MALWARE_TAMPER")}
            className="px-3 py-1.5 text-xs font-semibold bg-rose-500/10 border border-rose-500/20 text-rose-400 hover:bg-rose-500/20 rounded-md transition-all duration-150 flex items-center gap-1 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5 animate-spin-slow" /> Tamper Security Config
          </button>
          <button 
            onClick={() => triggerPresetSimulation("ROUTINE_BUILD")}
            className="px-3 py-1.5 text-xs font-semibold bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 hover:bg-emerald-500/20 rounded-md transition-all duration-150 flex items-center gap-1 cursor-pointer"
          >
            <CheckCircle className="w-3.5 h-3.5" /> Create Build Artifact
          </button>
          <button 
            onClick={() => setShowSimPanel(!showSimPanel)}
            className="px-3 py-1.5 text-xs font-semibold bg-sky-500 text-black hover:bg-sky-400 rounded-md transition-all duration-150 flex items-center gap-1 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" /> {showSimPanel ? "Close Form" : "Custom Event"}
          </button>
        </div>
      </div>

      {/* Expandable Custom Event Form */}
      <AnimatePresence>
        {showSimPanel && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-[#0f0f0f] border border-white/8 rounded-xl p-5 overflow-hidden"
          >
            <form onSubmit={handleCustomSimulationSubmit} className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Event Type</label>
                <select 
                  className="w-full bg-[#050505] border border-white/8 rounded-md px-3 py-2 text-xs text-white focus:outline-none"
                  value={simEvent.event}
                  onChange={(e) => setSimEvent({ ...simEvent, event: e.target.value as EventType })}
                >
                  <option value={EventType.CREATED}>CREATED</option>
                  <option value={EventType.MODIFIED}>MODIFIED</option>
                  <option value={EventType.MOVED}>MOVED</option>
                  <option value={EventType.DELETED}>DELETED</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Source Path (include 'confidential' to trigger rules)</label>
                <input 
                  type="text" 
                  className="w-full bg-[#050505] border border-white/8 rounded-md px-3 py-2 text-xs text-white focus:outline-none"
                  value={simEvent.src}
                  onChange={(e) => setSimEvent({ ...simEvent, src: e.target.value })}
                  placeholder="/Users/user/Confidential/contracts.docx"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Destination Path (include 'usb' to trigger rules)</label>
                <input 
                  type="text" 
                  className="w-full bg-[#050505] border border-white/8 rounded-md px-3 py-2 text-xs text-white focus:outline-none"
                  value={simEvent.dest}
                  onChange={(e) => setSimEvent({ ...simEvent, dest: e.target.value })}
                  placeholder="/media/usb0/contracts.docx"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Triggering Account</label>
                <input 
                  type="text" 
                  className="w-full bg-[#050505] border border-white/8 rounded-md px-3 py-2 text-xs text-white focus:outline-none"
                  value={simEvent.user}
                  onChange={(e) => setSimEvent({ ...simEvent, user: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-1">System Hostname</label>
                <input 
                  type="text" 
                  className="w-full bg-[#050505] border border-white/8 rounded-md px-3 py-2 text-xs text-white focus:outline-none"
                  value={simEvent.host}
                  onChange={(e) => setSimEvent({ ...simEvent, host: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Process Name</label>
                <input 
                  type="text" 
                  className="w-full bg-[#050505] border border-white/8 rounded-md px-3 py-2 text-xs text-white focus:outline-none"
                  value={simEvent.process}
                  onChange={(e) => setSimEvent({ ...simEvent, process: e.target.value })}
                />
              </div>

              <div className="md:col-span-3 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Pre-Event SHA-256 Hash</label>
                  <input 
                    type="text" 
                    className="w-full bg-[#050505] border border-white/8 rounded-md px-3 py-2 text-xs font-mono text-white focus:outline-none"
                    value={simEvent.hash_before}
                    onChange={(e) => setSimEvent({ ...simEvent, hash_before: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Post-Event SHA-256 Hash (different to trigger MISMATCH)</label>
                  <input 
                    type="text" 
                    className="w-full bg-[#050505] border border-white/8 rounded-md px-3 py-2 text-xs font-mono text-white focus:outline-none"
                    value={simEvent.hash_after}
                    onChange={(e) => setSimEvent({ ...simEvent, hash_after: e.target.value })}
                  />
                </div>
              </div>

              <div className="md:col-span-3">
                <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Compliance Detail / Details Warning Log</label>
                <input 
                  type="text" 
                  className="w-full bg-[#050505] border border-white/8 rounded-md px-3 py-2 text-xs text-white focus:outline-none"
                  value={simEvent.details}
                  onChange={(e) => setSimEvent({ ...simEvent, details: e.target.value })}
                  placeholder="Employee uploaded patented formula sequence."
                />
              </div>

              <div className="md:col-span-3 flex justify-end gap-2 mt-2">
                <button 
                  type="button" 
                  onClick={() => setShowSimPanel(false)}
                  className="px-4 py-2 text-xs text-slate-400 bg-white/5 hover:bg-white/10 border border-white/8 font-medium rounded-md cursor-pointer"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="px-4 py-2 text-xs text-black bg-sky-500 hover:bg-sky-400 font-semibold rounded-md cursor-pointer"
                >
                  Inject Simulated Event
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Audit Log Table Header & Filters */}
      <div className="bg-[#0f0f0f] rounded-xl border border-white/8 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-white/8 space-y-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h3 className="text-sm font-semibold text-white">Unified SFTMS Audit Ledger</h3>
              <p className="text-xs text-slate-500">Structured logs (JSONL stream representation). Currently showing {filteredEvents.length} filtered records.</p>
            </div>
            
            <button 
              onClick={onClearEvents}
              className="px-3 py-1.5 border border-red-500/20 bg-red-500/5 text-red-400 hover:bg-red-500/10 text-xs font-semibold rounded-md flex items-center gap-1 cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" /> Clear Audit Logs
            </button>
          </div>

          {/* Search and Advanced Select Filters */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
            {/* Search Path */}
            <div className="relative md:col-span-1">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500">
                <Search className="w-4 h-4" />
              </span>
              <input 
                type="text" 
                className="w-full bg-white/5 border border-white/8 rounded-md pl-9 pr-3 py-1.5 text-xs text-white placeholder:text-slate-500 focus:outline-none"
                placeholder="Search file path / user..."
                value={searchTerm}
                onChange={(e) => { setSearchTerm(e.target.value); resetPage(); }}
              />
            </div>

            {/* Severity Filter */}
            <div className="flex items-center gap-1 bg-white/5 border border-white/8 rounded-md px-2.5 py-1">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Severity</span>
              <select 
                className="bg-transparent text-xs text-slate-300 font-semibold border-0 py-0.5 focus:outline-none flex-1"
                value={filterSeverity}
                onChange={(e) => { setFilterSeverity(e.target.value); resetPage(); }}
              >
                <option value="ALL" className="bg-[#151515] text-white">ALL</option>
                <option value={SeverityLevel.HIGH} className="bg-[#151515] text-white">HIGH</option>
                <option value={SeverityLevel.MEDIUM} className="bg-[#151515] text-white">MEDIUM</option>
                <option value={SeverityLevel.LOW} className="bg-[#151515] text-white">LOW</option>
              </select>
            </div>

            {/* Auth Filter */}
            <div className="flex items-center gap-1 bg-white/5 border border-white/8 rounded-md px-2.5 py-1">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Policy</span>
              <select 
                className="bg-transparent text-xs text-slate-300 font-semibold border-0 py-0.5 focus:outline-none flex-1"
                value={filterAuth}
                onChange={(e) => { setFilterAuth(e.target.value); resetPage(); }}
              >
                <option value="ALL" className="bg-[#151515] text-white">ALL</option>
                <option value={AuthorizationStatus.AUTHORIZED} className="bg-[#151515] text-white">AUTHORIZED</option>
                <option value={AuthorizationStatus.REVIEW} className="bg-[#151515] text-white">REVIEW</option>
                <option value={AuthorizationStatus.UNAUTHORIZED} className="bg-[#151515] text-white">VIOLATIONS</option>
              </select>
            </div>

            {/* Integrity Filter */}
            <div className="flex items-center gap-1 bg-white/5 border border-white/8 rounded-md px-2.5 py-1">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Hash</span>
              <select 
                className="bg-transparent text-xs text-slate-300 font-semibold border-0 py-0.5 focus:outline-none flex-1"
                value={filterIntegrity}
                onChange={(e) => { setFilterIntegrity(e.target.value); resetPage(); }}
              >
                <option value="ALL" className="bg-[#151515] text-white">ALL</option>
                <option value={IntegrityStatus.MATCH} className="bg-[#151515] text-white">MATCH</option>
                <option value={IntegrityStatus.MISMATCH} className="bg-[#151515] text-white">MISMATCH</option>
                <option value={IntegrityStatus.NA} className="bg-[#151515] text-white">N/A</option>
              </select>
            </div>

            {/* Sensitivity Filter */}
            <div className="flex items-center gap-1 bg-white/5 border border-white/8 rounded-md px-2.5 py-1">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Type</span>
              <select 
                className="bg-transparent text-xs text-slate-300 font-semibold border-0 py-0.5 focus:outline-none flex-1"
                value={filterSensitivity}
                onChange={(e) => { setFilterSensitivity(e.target.value); resetPage(); }}
              >
                <option value="ALL" className="bg-[#151515] text-white">ALL FILES</option>
                <option value="SENSITIVE" className="bg-[#151515] text-white">SENSITIVE ONLY</option>
                <option value="NORMAL" className="bg-[#151515] text-white">NORMAL ONLY</option>
              </select>
            </div>
          </div>
        </div>

        {/* Log list table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-white/2 text-[10px] font-mono text-slate-500 uppercase tracking-wider border-b border-white/8">
                <th className="py-3 px-4 font-semibold">Timestamp</th>
                <th className="py-3 px-4 font-semibold">Event</th>
                <th className="py-3 px-4 font-semibold">Target Resource (File)</th>
                <th className="py-3 px-4 font-semibold">Subject Account</th>
                <th className="py-3 px-4 font-semibold text-center">Authorization</th>
                <th className="py-3 px-4 font-semibold text-center">Hash Integrity</th>
                <th className="py-3 px-4 font-semibold text-right">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 bg-[#0f0f0f]">
              {paginatedEvents.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-xs text-slate-500">
                    No matching file transfer logs found in active database view.
                  </td>
                </tr>
              ) : (
                paginatedEvents.map((evt) => (
                  <tr 
                    key={evt.id} 
                    className="hover:bg-white/5 transition-colors duration-150 cursor-pointer border-b border-white/5 last:border-0"
                    onClick={() => setSelectedEvent(evt)}
                  >
                    {/* Time */}
                    <td className="py-3.5 px-4 text-xs font-mono text-slate-400 whitespace-nowrap">
                      {new Date(evt.timestamp).toLocaleDateString()} {new Date(evt.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                    </td>

                    {/* Event Type */}
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded font-bold uppercase ${
                        evt.event === EventType.CREATED ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" :
                        evt.event === EventType.DELETED ? "bg-red-500/10 text-red-400 border border-red-500/20" :
                        evt.event === EventType.MOVED ? "bg-sky-500/10 text-sky-400 border border-sky-500/20 shadow-[0_0_10px_rgba(56,189,248,0.1)]" :
                        "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                      }`}>
                        {evt.event}
                      </span>
                    </td>

                    {/* Path */}
                    <td className="py-3.5 px-4 max-w-[280px]">
                      <div className="flex flex-col">
                        <span className={`text-xs font-semibold font-mono truncate ${evt.sensitive ? "text-red-400" : "text-white"}`} title={evt.src}>
                          {evt.src}
                        </span>
                        {evt.dest && (
                          <span className="text-[10px] text-slate-500 font-mono truncate flex items-center gap-0.5 mt-0.5" title={evt.dest}>
                            <CornerDownRight className="w-3 h-3 shrink-0" /> {evt.dest}
                          </span>
                        )}
                      </div>
                    </td>

                    {/* User and Host */}
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <div className="flex flex-col">
                        <span className="text-xs text-slate-200 font-medium font-mono">{evt.user}</span>
                        <span className="text-[10px] text-slate-500 font-mono">{evt.host}</span>
                      </div>
                    </td>

                    {/* Authorization Badge */}
                    <td className="py-3.5 px-4 whitespace-nowrap text-center">
                      <span className={`text-[10px] font-bold tracking-wide px-2 py-0.5 rounded-full inline-flex items-center gap-1 ${
                        evt.authorization === AuthorizationStatus.AUTHORIZED ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" :
                        evt.authorization === AuthorizationStatus.UNAUTHORIZED ? "bg-red-500/10 text-red-400 border border-red-500/20" :
                        "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                      }`}>
                        {evt.authorization === AuthorizationStatus.UNAUTHORIZED && <ShieldAlert className="w-2.5 h-2.5" />}
                        {evt.authorization}
                      </span>
                    </td>

                    {/* Integrity Badge */}
                    <td className="py-3.5 px-4 whitespace-nowrap text-center">
                      <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${
                        evt.integrity === IntegrityStatus.MATCH ? "text-emerald-400 bg-emerald-500/10 border border-emerald-500/20" :
                        evt.integrity === IntegrityStatus.MISMATCH ? "text-rose-400 bg-rose-500/10 border border-rose-500/20 shadow-[0_0_10px_rgba(244,63,94,0.1)]" :
                        "text-slate-500 bg-white/5 border border-white/8"
                      }`}>
                        {evt.integrity}
                      </span>
                    </td>

                    {/* Action Link Icon */}
                    <td className="py-3.5 px-4 text-right whitespace-nowrap">
                      <button className="text-slate-500 hover:text-slate-300 p-1">
                        <ExternalLink className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Controls */}
        <div className="px-5 py-4 border-t border-white/8 bg-white/2 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-slate-500">Rows per page:</span>
            <select 
              className="bg-[#050505] border border-white/8 rounded px-1.5 py-0.5 text-xs text-slate-300 focus:outline-none font-semibold"
              value={itemsPerPage}
              onChange={(e) => { setItemsPerPage(Number(e.target.value)); resetPage(); }}
            >
              <option value={10}>10</option>
              <option value={20}>20</option>
              <option value={50}>50</option>
            </select>
            <span className="text-slate-500 font-mono ml-2">
              Showing {(currentPage - 1) * itemsPerPage + 1} - {Math.min(currentPage * itemsPerPage, filteredEvents.length)} of {filteredEvents.length} logs
            </span>
          </div>

          <div className="flex items-center gap-1 font-semibold">
            <button 
              className="px-2.5 py-1 rounded border border-white/8 bg-white/5 hover:bg-white/10 disabled:opacity-40 disabled:hover:bg-white/5 text-slate-300 cursor-pointer"
              disabled={currentPage === 1}
              onClick={() => setCurrentPage(currentPage - 1)}
            >
              Previous
            </button>
            <span className="px-3 text-slate-500 font-mono">
              Page {currentPage} of {totalPages}
            </span>
            <button 
              className="px-2.5 py-1 rounded border border-white/8 bg-white/5 hover:bg-white/10 disabled:opacity-40 disabled:hover:bg-white/5 text-slate-300 cursor-pointer"
              disabled={currentPage === totalPages}
              onClick={() => setCurrentPage(currentPage + 1)}
            >
              Next
            </button>
          </div>
        </div>
      </div>

      {/* Structured Incident Audit Details Modal */}
      <AnimatePresence>
        {selectedEvent && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#050505]/85 p-4 backdrop-blur-xs">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#0f0f0f] rounded-xl border border-white/8 shadow-2xl w-full max-w-2xl overflow-hidden flex flex-col max-h-[90vh]"
            >
              {/* Header */}
              <div className={`px-6 py-4 text-white flex items-center justify-between border-b border-white/8 ${
                selectedEvent.authorization === AuthorizationStatus.UNAUTHORIZED ? "bg-[#1a0f0f]" :
                selectedEvent.authorization === AuthorizationStatus.REVIEW ? "bg-[#1a150f]" : "bg-[#0f171a]"
              }`}>
                <div className="flex items-center gap-2">
                  <ShieldAlert className={`w-5 h-5 ${
                    selectedEvent.authorization === AuthorizationStatus.UNAUTHORIZED ? "text-red-400" :
                    selectedEvent.authorization === AuthorizationStatus.REVIEW ? "text-amber-400" : "text-sky-400"
                  }`} />
                  <div>
                    <h3 className={`text-sm font-bold uppercase tracking-wider font-mono ${
                      selectedEvent.authorization === AuthorizationStatus.UNAUTHORIZED ? "text-red-400" :
                      selectedEvent.authorization === AuthorizationStatus.REVIEW ? "text-amber-400" : "text-sky-400"
                    }`}>
                      File Security Audit Panel
                    </h3>
                    <p className="text-[10px] text-slate-500 font-mono">ID: {selectedEvent.id}</p>
                  </div>
                </div>
                <button 
                  onClick={() => setSelectedEvent(null)}
                  className="p-1 hover:bg-white/10 rounded text-slate-400 hover:text-white text-xs font-bold cursor-pointer"
                >
                  ✕ Close
                </button>
              </div>

              {/* Content Body */}
              <div className="p-6 overflow-y-auto space-y-6">
                {/* Visual Status Indicator Card */}
                <div className={`p-4 rounded-lg flex items-start gap-3 border ${
                  selectedEvent.authorization === AuthorizationStatus.UNAUTHORIZED ? "bg-red-500/5 border-red-500/10 text-red-400" :
                  selectedEvent.authorization === AuthorizationStatus.REVIEW ? "bg-amber-500/5 border-amber-500/10 text-amber-400" :
                  "bg-emerald-500/5 border-emerald-500/10 text-emerald-400"
                }`}>
                  {selectedEvent.authorization === AuthorizationStatus.UNAUTHORIZED ? (
                    <XCircle className="w-5 h-5 shrink-0 mt-0.5 text-red-400" />
                  ) : selectedEvent.authorization === AuthorizationStatus.REVIEW ? (
                    <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5 text-amber-400" />
                  ) : (
                    <CheckCircle className="w-5 h-5 shrink-0 mt-0.5 text-emerald-400" />
                  )}
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider">
                      Policy Evaluation: {selectedEvent.authorization}
                    </h4>
                    <p className="text-xs mt-1 font-semibold text-slate-300">
                      {selectedEvent.details || "This file operation matches routine, authorized compliance standards."}
                    </p>
                  </div>
                </div>

                {/* Primary Metadata Table */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Left Column */}
                  <div className="space-y-3.5 text-xs">
                    <div className="flex items-center gap-2 pb-2 border-b border-white/5">
                      <Calendar className="w-4 h-4 text-slate-500" />
                      <div>
                        <span className="text-[10px] text-slate-500 block font-mono">Timestamp</span>
                        <span className="font-mono text-slate-300 font-medium">{selectedEvent.timestamp}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pb-2 border-b border-white/5">
                      <Layers className="w-4 h-4 text-slate-500" />
                      <div>
                        <span className="text-[10px] text-slate-500 block font-mono">File Action (OS Watcher)</span>
                        <span className="font-mono text-slate-300 font-bold uppercase">{selectedEvent.event}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pb-2 border-b border-white/5">
                      <User className="w-4 h-4 text-slate-500" />
                      <div>
                        <span className="text-[10px] text-slate-500 block font-mono">Subject Account</span>
                        <span className="font-mono text-slate-300 font-medium">{selectedEvent.user} @ {selectedEvent.host}</span>
                      </div>
                    </div>
                  </div>

                  {/* Right Column */}
                  <div className="space-y-3.5 text-xs">
                    <div className="flex items-center gap-2 pb-2 border-b border-white/5">
                      <Cpu className="w-4 h-4 text-slate-500" />
                      <div>
                        <span className="text-[10px] text-slate-500 block font-mono">Process Details</span>
                        <span className="font-mono text-slate-300 font-medium">{selectedEvent.process} (PID: {selectedEvent.pid})</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pb-2 border-b border-white/5">
                      <Fingerprint className="w-4 h-4 text-slate-500" />
                      <div>
                        <span className="text-[10px] text-slate-500 block font-mono">Integrity Status</span>
                        <span className="font-mono text-slate-300 font-bold uppercase">{selectedEvent.integrity}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pb-2 border-b border-white/5">
                      <Info className="w-4 h-4 text-slate-500" />
                      <div>
                        <span className="text-[10px] text-slate-500 block font-mono">Classification Flags</span>
                        <span className="font-mono text-slate-300 font-medium text-[10px]">
                          Sensitive: {selectedEvent.sensitive ? "YES 🔴" : "NO 🟢"} | Suspicious Dest: {selectedEvent.suspicious_destination ? "YES ⚠️" : "NO 🟢"}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Path display box */}
                <div className="bg-black/40 rounded-lg p-3.5 border border-white/5 space-y-2">
                  <div className="text-xs">
                    <span className="text-[10px] font-mono text-slate-500 block uppercase font-bold">Source Path</span>
                    <code className="text-xs text-white font-mono font-semibold break-all block mt-0.5">{selectedEvent.src}</code>
                  </div>
                  {selectedEvent.dest && (
                    <div className="text-xs border-t border-white/5 pt-2 mt-2">
                      <span className="text-[10px] font-mono text-slate-500 block uppercase font-bold">Destination Path</span>
                      <code className="text-xs text-white font-mono font-semibold break-all block mt-0.5">{selectedEvent.dest}</code>
                    </div>
                  )}
                </div>

                {/* SHA-256 Hashes Comparison */}
                <div className="space-y-2">
                  <h4 className="text-xs font-bold uppercase text-slate-500 tracking-wider font-sans">
                    Cryptographic Hashing (SHA-256 Audit Trail)
                  </h4>
                  <div className="bg-black/40 rounded-lg p-3 text-slate-300 font-mono text-[11px] space-y-2.5 border border-white/5">
                    <div>
                      <span className="text-sky-400 block uppercase text-[9px] font-bold">Hash Before Transfer Event</span>
                      <code className="break-all text-emerald-400 block">
                        {selectedEvent.hash_before || "0000000000000000000000000000000000000000000000000000000000000000 (File Created)"}
                      </code>
                    </div>
                    <div className="border-t border-white/5 pt-2">
                      <span className="text-sky-400 block uppercase text-[9px] font-bold">Hash After Transfer Event</span>
                      <code className={`break-all block ${selectedEvent.integrity === IntegrityStatus.MISMATCH ? "text-red-400" : "text-emerald-400"}`}>
                        {selectedEvent.hash_after || "0000000000000000000000000000000000000000000000000000000000000000 (File Deleted)"}
                      </code>
                    </div>
                  </div>
                </div>

                {/* Structured Schema output (JSONL simulation element node) */}
                <div className="space-y-2">
                  <h4 className="text-xs font-bold uppercase text-slate-500 tracking-wider font-sans">
                    Raw Audit Record (JSONL Element Entry)
                  </h4>
                  <pre className="bg-[#050505] text-sky-300 rounded-lg p-3 text-[10px] font-mono overflow-x-auto whitespace-pre-wrap border border-white/5">
                    {JSON.stringify({
                      timestamp: selectedEvent.timestamp,
                      event: selectedEvent.event,
                      src: selectedEvent.src,
                      dest: selectedEvent.dest,
                      user: selectedEvent.user,
                      host: selectedEvent.host,
                      pid: selectedEvent.pid,
                      process: selectedEvent.process,
                      hash_before: selectedEvent.hash_before,
                      hash_after: selectedEvent.hash_after,
                      integrity: selectedEvent.integrity,
                      sensitive: selectedEvent.sensitive,
                      suspicious_destination: selectedEvent.suspicious_destination,
                      authorization: selectedEvent.authorization,
                      severity: selectedEvent.severity
                    }, null, 2)}
                  </pre>
                </div>
              </div>

              {/* Footer actions */}
              <div className="px-6 py-4 bg-white/2 border-t border-white/8 flex justify-end gap-2">
                <button 
                  onClick={() => setSelectedEvent(null)}
                  className="px-4 py-2 text-xs bg-sky-500 text-black font-semibold hover:bg-sky-400 rounded-md cursor-pointer"
                >
                  Dismiss Audit Panel
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
