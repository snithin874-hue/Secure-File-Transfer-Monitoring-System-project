/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Fingerprint, 
  FileCheck, 
  FileWarning, 
  Edit3, 
  RefreshCw, 
  Play, 
  AlertTriangle, 
  CheckCircle,
  Clock,
  Unlock,
  Eye,
  Trash
} from "lucide-react";

interface MockFile {
  path: string;
  description: string;
  originalContent: string;
  category: "System Auth" | "Database" | "Proprietary" | "Config";
}

const INTEGRITY_TEMPLATES: MockFile[] = [
  {
    path: "/etc/pam.d/common-auth",
    category: "System Auth",
    description: "Linux PAM authentication configuration. Crucial file determining login credentials structure.",
    originalContent: `# /etc/pam.d/common-auth
auth\trequired\tpam_unix.so nullok_secure
auth\toptional\tpam_permit.so
auth\trequired\tpam_deny.so
session\trequired\tpam_limits.so`
  },
  {
    path: "/var/secure/credit_cards.csv",
    category: "Database",
    description: "PCI-DSS compliance-controlled ledger storing transactional token references.",
    originalContent: `CardToken,Expiration,AuthorizationCode,Issuer
tok_93d8f1e,12/28,AUTH_APPROVED_8123,Visa
tok_28ea912,04/29,AUTH_APPROVED_1102,Mastercard
tok_f20e981,09/27,AUTH_DENIED_0049,Amex`
  },
  {
    path: "/Users/admin/Confidential/Patents_Pending_2026.pdf",
    category: "Proprietary",
    description: "Confidential corporate patent schemas and physical design specifications.",
    originalContent: `%PDF-1.4
%Patent Specification Schema #2026-902-SFT
4 0 obj
<< /Type /Page /Parent 3 0 R /MediaBox [0 0 612 792] >>
stream
CONFIDENTIAL: Quantum Battery Cell Formulation Code: 99x-A7
endstream`
  },
  {
    path: "/etc/ssh/sshd_config",
    category: "Config",
    description: "System SSH server daemon rules specifying authorized root login parameters.",
    originalContent: `# /etc/ssh/sshd_config
Port 22
PermitRootLogin no
PubkeyAuthentication yes
AuthorizedKeysFile .ssh/authorized_keys
PasswordAuthentication no`
  }
];

export default function IntegrityCheck() {
  const [selectedTemplate, setSelectedTemplate] = useState<MockFile>(INTEGRITY_TEMPLATES[0]);
  const [currentContent, setCurrentContent] = useState(INTEGRITY_TEMPLATES[0].originalContent);
  const [originalHash, setOriginalHash] = useState("");
  const [currentHash, setCurrentHash] = useState("");
  const [hashingInProgress, setHashingInProgress] = useState(false);
  const [auditRun, setAuditRun] = useState(false);

  // Web Crypto API helper to compute real SHA-256
  const computeRealSHA256 = async (text: string): Promise<string> => {
    try {
      const msgBuffer = new TextEncoder().encode(text);
      const hashBuffer = await crypto.subtle.digest("SHA-256", msgBuffer);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
    } catch (e) {
      // Fallback simple hash string if Web Crypto fails in iframe constraints
      let hash = 0;
      for (let i = 0; i < text.length; i++) {
        hash = (hash << 5) - hash + text.charCodeAt(i);
        hash |= 0;
      }
      return Math.abs(hash).toString(16).padStart(8, "0") + "f3e82b712a4d0c283f6b92a34e8f19da562c64de2c7198fb901e";
    }
  };

  // Compute original stable hash when template changes
  useEffect(() => {
    const initHashes = async () => {
      const orig = await computeRealSHA256(selectedTemplate.originalContent);
      setOriginalHash(orig);
      setCurrentContent(selectedTemplate.originalContent);
      setCurrentHash(orig);
      setAuditRun(false);
    };
    initHashes();
  }, [selectedTemplate]);

  // Compute current live hash as user types (debounced or live)
  useEffect(() => {
    const updateLiveHash = async () => {
      const hash = await computeRealSHA256(currentContent);
      setCurrentHash(hash);
    };
    updateLiveHash();
  }, [currentContent]);

  const handleAuditAction = () => {
    setHashingInProgress(true);
    setAuditRun(false);
    setTimeout(() => {
      setHashingInProgress(false);
      setAuditRun(true);
    }, 850); // mock calculation duration
  };

  const isTampered = originalHash !== currentHash;

  return (
    <div className="space-y-6">
      <div className="bg-[#0f0f0f] rounded-xl border border-white/8 p-5 shadow-xs">
        <h3 className="text-sm font-semibold text-white">Dynamic File Integrity Checker</h3>
        <p className="text-xs text-slate-500 mt-0.5">
          Select a sensitive file, tamper with its text contents below, and run the Cryptographic Hash Audit to test whether the integrity checker detects modifications.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left panel: File Selectors */}
        <div className="space-y-4">
          <div className="bg-[#0f0f0f] rounded-xl border border-white/8 p-5 shadow-xs">
            <h4 className="text-xs font-bold uppercase text-slate-400 tracking-wider mb-3 font-sans">
              Target System Files Catalog
            </h4>
            <div className="space-y-2.5">
              {INTEGRITY_TEMPLATES.map((tpl) => (
                <button
                  key={tpl.path}
                  onClick={() => setSelectedTemplate(tpl)}
                  className={`w-full text-left p-3.5 rounded-lg border text-xs transition-all duration-150 cursor-pointer flex items-start gap-2.5 ${
                    selectedTemplate.path === tpl.path 
                      ? "bg-white/5 border-sky-500/30 text-sky-400 shadow-xs" 
                      : "bg-white/2 border-white/5 text-slate-300 hover:bg-white/5"
                  }`}
                >
                  <Fingerprint className={`w-4 h-4 shrink-0 mt-0.5 ${
                    selectedTemplate.path === tpl.path ? "text-sky-400" : "text-slate-500"
                  }`} />
                  <div>
                    <span className="font-mono font-bold block truncate">{tpl.path}</span>
                    <span className="text-[10px] text-slate-500 block mt-0.5">{tpl.category} • {tpl.description}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Educational Insight Callout */}
          <div className="bg-[#0f0f0f] text-slate-400 rounded-xl border border-white/8 p-5 shadow-xs text-xs space-y-3">
            <h4 className="text-[10px] font-bold text-sky-400 uppercase tracking-wider font-mono">
              Blue-Team Security Tip
            </h4>
            <p className="leading-relaxed">
              DLP monitors run streaming SHA-256 checks before and after file transfers. Even changing a single character (like changing <code>no</code> to <code>yes</code> in sshd_config) entirely alters the computed hash (known as the <strong>Avalanche Effect</strong>).
            </p>
            <p className="leading-relaxed">
              If the hash fails to match its pre-compiled baseline, an <strong>Integrity MISMATCH</strong> alarm is raised immediately.
            </p>
          </div>
        </div>

        {/* Center/Right panel: Editor & Comparison */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-[#0f0f0f] rounded-xl border border-white/8 p-6 space-y-4 shadow-xs">
            <div className="flex items-center justify-between border-b border-white/8 pb-3">
              <div>
                <span className="text-[10px] font-mono text-slate-500 block uppercase font-bold">Currently Auditing</span>
                <code className="text-xs font-mono font-bold text-white">{selectedTemplate.path}</code>
              </div>
              <button 
                onClick={() => setCurrentContent(selectedTemplate.originalContent)}
                className="px-2.5 py-1 border border-white/8 text-slate-300 bg-white/5 hover:bg-white/10 text-[10px] font-mono font-semibold rounded flex items-center gap-1 cursor-pointer"
                title="Reset to Baseline"
              >
                <RefreshCw className="w-3 h-3" /> Restore baseline
              </button>
            </div>

            {/* Editable TextArea representing simulated filesystem block */}
            <div className="relative">
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5 flex items-center gap-1">
                <Edit3 className="w-3.5 h-3.5" /> Simulated File Contents (Modify below):
              </label>
              <textarea
                value={currentContent}
                onChange={(e) => {
                  setCurrentContent(e.target.value);
                  setAuditRun(false); // require re-audit
                }}
                rows={7}
                className="w-full bg-[#050505] text-emerald-400 font-mono text-xs rounded-lg p-4 border border-white/8 focus:outline-none focus:border-sky-500/50 shadow-inner"
              />
              <div className="absolute bottom-3.5 right-3.5 text-[9px] font-mono bg-[#151515] text-slate-400 border border-white/5 px-2 py-0.5 rounded uppercase">
                {currentContent.length} bytes
              </div>
            </div>

            {/* Visual Real-time Hash Output */}
            <div className="bg-[#050505] rounded-lg p-4 border border-white/8 grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <span className="text-[9px] font-mono text-slate-500 block uppercase font-bold">Baseline Hash Signature</span>
                <code className="text-[10px] font-mono font-semibold text-slate-400 break-all block mt-1">{originalHash}</code>
              </div>
              <div>
                <span className="text-[9px] font-mono text-slate-500 block uppercase font-bold">Current Computed Hash</span>
                <code className={`text-[10px] font-mono font-semibold break-all block mt-1 ${
                  isTampered ? "text-amber-400" : "text-emerald-400"
                }`}>
                  {currentHash}
                </code>
              </div>
            </div>

            {/* Run Audit Button */}
            <div className="flex justify-end pt-2">
              <button
                onClick={handleAuditAction}
                disabled={hashingInProgress}
                className={`px-5 py-2.5 text-xs font-semibold rounded-md text-black flex items-center gap-2 cursor-pointer shadow-sm ${
                  hashingInProgress ? "bg-sky-400/50 cursor-not-allowed" : "bg-sky-500 hover:bg-sky-400"
                }`}
              >
                {hashingInProgress ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Verifying Signatures...
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5" /> Run Cryptographic Hash Audit
                  </>
                )}
              </button>
            </div>

            {/* Audit Verdict Banner */}
            <AnimatePresence>
              {auditRun && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className={`p-4 rounded-lg border flex items-start gap-3.5 ${
                    isTampered 
                      ? "bg-red-500/5 border-red-500/15 text-red-400" 
                      : "bg-emerald-500/5 border-emerald-500/15 text-emerald-400"
                  }`}
                >
                  {isTampered ? (
                    <>
                      <FileWarning className="w-6 h-6 shrink-0 text-red-400 animate-pulse mt-0.5" />
                      <div className="space-y-1">
                        <h4 className="text-xs font-bold uppercase tracking-wider text-red-400">
                          INTEGRITY TAMPER ALERT: MISMATCH DETECTED 🔴
                        </h4>
                        <p className="text-xs text-slate-300 leading-relaxed font-semibold">
                          The current file signature does not match its pre-compiled baseline of <code>{originalHash.slice(0, 12)}...</code>. SFTMS has registered an unauthorized modification alert.
                        </p>
                      </div>
                    </>
                  ) : (
                    <>
                      <CheckCircle className="w-6 h-6 shrink-0 text-emerald-400 mt-0.5" />
                      <div className="space-y-1">
                        <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                          INTEGRITY VERIFIED: MATCH OK 🟢
                        </h4>
                        <p className="text-xs text-slate-300 leading-relaxed">
                          The cryptographic baseline signatures are identical. The file remains in its authorized pristine state.
                        </p>
                      </div>
                    </>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
}
