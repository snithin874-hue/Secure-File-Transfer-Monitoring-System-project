/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useMemo } from "react";
import { motion } from "motion/react";
import { 
  FileText, 
  Download, 
  Copy, 
  Check, 
  ShieldCheck, 
  RefreshCw,
  FolderSync,
  Terminal,
  Printer
} from "lucide-react";
import { SFTMSEvent, AuthorizationStatus, IntegrityStatus } from "../types";

interface AuditReportProps {
  events: SFTMSEvent[];
}

export default function AuditReport({ events }: AuditReportProps) {
  const [copying, setCopying] = useState(false);

  // Compile statistics from active event stream
  const reportData = useMemo(() => {
    const total = events.length;
    const unauthorized = events.filter(e => e.authorization === AuthorizationStatus.UNAUTHORIZED);
    const review = events.filter(e => e.authorization === AuthorizationStatus.REVIEW);
    const mismatch = events.filter(e => e.integrity === IntegrityStatus.MISMATCH);
    const sensitive = events.filter(e => e.sensitive);

    // Grouping helper
    const getFrequency = (key: keyof SFTMSEvent) => {
      const freq: { [key: string]: number } = {};
      events.forEach(e => {
        const val = String(e[key]);
        freq[val] = (freq[val] || 0) + 1;
      });
      return Object.entries(freq).sort((a, b) => b[1] - a[1]).slice(0, 3);
    };

    const topUsers = getFrequency("user");
    const topProcesses = getFrequency("process");
    const topHosts = getFrequency("host");

    return {
      total,
      unauthorized,
      review,
      mismatch,
      sensitive,
      topUsers,
      topProcesses,
      topHosts
    };
  }, [events]);

  // Generate plain-text compliance report matching exactly sftms_audit_report.txt schema
  const compiledReportText = useMemo(() => {
    const timeStr = new Date().toISOString().replace("T", " ").substring(0, 19) + " UTC";
    
    let text = `================================================================================
SECURE FILE TRANSFER MONITORING SYSTEM (SFTMS) - AUDIT COMPLIANCE REPORT
Generated on: ${timeStr}
Reporting Target Zone: SYSTEM-WIDE SFTMS DAEMON
Security Operations Center (SOC) Log Level: FULL AUDIT
================================================================================

1. EXECUTIVE SUMMARY
---------------------
The Secure File Transfer Monitoring System (SFTMS) monitored filesystem actions
on real-time endpoints. A cumulative total of ${reportData.total} events were 
scanned, evaluated against security threat policies, and archived.

Audit Metrics Summary:
• Total Events Audited:         ${reportData.total}
• Policy Violations Detected:   ${reportData.unauthorized.length} (CRITICAL ALERT)
• Pending Policy Reviews:       ${reportData.review.length} (WARNING STATUS)
• Signature Mismatches (Tamper):${reportData.mismatch.length} (SUSPECTED TAMPERING)
• Restricted Files Touched:     ${reportData.sensitive.length}

Compliance Status: ${
      reportData.unauthorized.length > 0 
        ? "🔴 NON-COMPLIANT (Active exfiltration or unauthorized file actions detected)" 
        : "🟢 COMPLIANT (No active policy violations detected)"
    }

2. DETAILED SECURITY VIOLATIONS AUDIT
--------------------------------------
`;

    if (reportData.unauthorized.length === 0) {
      text += "NO POLICY VIOLATIONS OR SECURITY BREACHES ENCOUNTERED IN THE CURRENT AUDIT LEDGER.\nAll movements of sensitive files occurred inside authorized channels.\n\n";
    } else {
      reportData.unauthorized.forEach((ue, idx) => {
        text += `[VIOLATION #${idx + 1}]
Timestamp:   ${ue.timestamp}
Account:     ${ue.user} @ ${ue.host}
Process:     ${ue.process} (PID: ${ue.pid})
Event Action: ${ue.event.toUpperCase()}
Resource:    ${ue.src}
`;
        if (ue.dest) {
          text += `Destination: ${ue.dest}\n`;
        }
        text += `Integrity:   ${ue.integrity} (Baseline signatures compared)
Incident:    ${ue.details || "Unauthorized transfer of a restricted file to an untrusted destination."}
--------------------------------------------------------------------------------
`;
      });
    }

    if (reportData.mismatch.length > 0) {
      text += `\n3. INTEGRITY FAILURE LOGS (HASH COMPROMISE)
-------------------------------------------
Cryptographic integrity checks failed on the following paths, indicating
unauthorized file editing, binary injection, or file corruption:
`;
      reportData.mismatch.forEach((me, idx) => {
        text += `[TAMPERING #${idx + 1}]
Timestamp:   ${me.timestamp}
File Path:   ${me.src}
Account:     ${me.user} (PID: ${me.pid} via '${me.process}')
Original Baseline Hash: ${me.hash_before}
Computed Current Hash:  ${me.hash_after}
--------------------------------------------------------------------------------
`;
      });
    }

    text += `\n4. SECURITY ACTIVITY ANALYTICS
-------------------------------
A. TOP ACCESSING ACCOUNTS (SUBJECTS):
${reportData.topUsers.map(([user, count]) => `   • User '${user}': ${count} logged actions`).join("\n")}

B. TOP OPERATIONAL PROCESSES (THREATS/TOOLS):
${reportData.topProcesses.map(([proc, count]) => `   • Process '${proc}': ${count} calls`).join("\n")}

C. TOP AUDITED ENDPOINTS (HOSTS):
${reportData.topHosts.map(([host, count]) => `   • Machine '${host}': ${count} events`).join("\n")}


5. COMPLIANCE & DEFENSIVE MITIGATION RECOMMENDATIONS
----------------------------------------------------
Based on the file audit events collected, the Security Team recommends:

1. [IMMEDIATE] Audit and revoke active USB media mount privileges for workstations displaying UNAUTHORIZED movements.
2. [IMMEDIATE] Replace or re-image files experiencing integrity mismatches (specifically checking common-auth and PAM configs).
3. Implement persistent folder protection triggers on paths matching 'confidential' or 'restricted'.
4. Ensure the background Python observer monitor daemon is deployed as an active SystemD / LaunchD service with syslog forwarding.

================================================================================
END OF SECURITY AUDIT COMPLIANCE REPORT - CONFIDENTIAL DATA ONLY
================================================================================
`;
    return text;
  }, [reportData]);

  const handleCopyToClipboard = () => {
    navigator.clipboard.writeText(compiledReportText);
    setCopying(true);
    setTimeout(() => setCopying(false), 2000);
  };

  const handleDownloadReport = () => {
    const blob = new Blob([compiledReportText], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `sftms_audit_report_${Date.now()}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Intro section */}
      <div className="bg-[#0f0f0f] rounded-xl border border-white/8 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h3 className="text-sm font-semibold text-white">Compliance Audit Reporter</h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Generates a formalized forensic plaintext file (<code>sftms_audit_report.txt</code>) analyzing policy compliance, hash alterations, and insider activities.
          </p>
        </div>

        <div className="flex gap-2 shrink-0">
          <button
            onClick={handleCopyToClipboard}
            className="px-3.5 py-2 text-xs font-semibold bg-white/5 border border-white/8 text-slate-300 hover:bg-white/10 rounded-md flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            {copying ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" /> Copied!
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" /> Copy Report
              </>
            )}
          </button>
          
          <button
            onClick={handleDownloadReport}
            className="px-3.5 py-2 text-xs font-semibold bg-sky-500 hover:bg-sky-400 text-black rounded-md flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
          >
            <Download className="w-3.5 h-3.5" /> Download Report (.txt)
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Side: Dynamic KPI insights */}
        <div className="space-y-4">
          {/* Compliance Status widget */}
          <div className="bg-[#0f0f0f] rounded-xl border border-white/8 p-5 shadow-xs space-y-3" id="report-compliance-status">
            <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono">
              Compliance Evaluation
            </h4>
            
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                reportData.unauthorized.length > 0 ? "bg-red-500/10 text-red-400" : "bg-emerald-500/10 text-emerald-400"
              }`}>
                {reportData.unauthorized.length > 0 ? (
                  <FileText className="w-5.5 h-5.5" />
                ) : (
                  <ShieldCheck className="w-5.5 h-5.5" />
                )}
              </div>
              <div>
                <span className={`text-sm font-bold block ${
                  reportData.unauthorized.length > 0 ? "text-red-400" : "text-emerald-400"
                }`}>
                  {reportData.unauthorized.length > 0 ? "NON-COMPLIANT" : "FULLY COMPLIANT"}
                </span>
                <span className="text-[10px] text-slate-500 block mt-0.5">
                  Based on {reportData.unauthorized.length} exfiltrations out of {reportData.total} logs.
                </span>
              </div>
            </div>
          </div>

          {/* Quick Metrics distribution */}
          <div className="bg-[#0f0f0f] rounded-xl border border-white/8 p-5 shadow-xs space-y-4" id="report-stats">
            <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono">
              Operational Statistics
            </h4>

            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between border-b border-white/5 pb-1.5">
                <span className="text-slate-400 font-medium">Critical Breaches</span>
                <span className="font-mono text-red-400 font-bold bg-red-500/10 border border-red-500/20 px-2 py-0.5 rounded">
                  {reportData.unauthorized.length}
                </span>
              </div>
              <div className="flex items-center justify-between border-b border-white/5 pb-1.5">
                <span className="text-slate-400 font-medium">Restricted Touches</span>
                <span className="font-mono text-slate-300 font-semibold bg-white/5 border border-white/8 px-2 py-0.5 rounded">
                  {reportData.sensitive.length}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400 font-medium">Integrity Failures</span>
                <span className="font-mono text-rose-400 font-bold bg-rose-500/10 border border-rose-500/20 px-2 py-0.5 rounded">
                  {reportData.mismatch.length}
                </span>
              </div>
            </div>
          </div>

          {/* Forensic timeline details */}
          <div className="bg-[#0f0f0f] text-slate-400 rounded-xl border border-white/8 p-5 shadow-xs space-y-3" id="report-terminal-output">
            <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono flex items-center gap-1">
              <Terminal className="w-3.5 h-3.5 text-sky-400" /> SFTMS Reporter Terminal
            </h4>
            <div className="font-mono text-[10px] space-y-2 bg-[#050505] p-3 rounded-lg border border-white/5">
              <p className="text-sky-400"># python3 -m sftms.report --out ./sftms_out</p>
              <p className="text-slate-500">[*] Scanning logs inside sftms_events.json...</p>
              <p className="text-slate-500">[*] Aggregated {reportData.total} items successfully.</p>
              <p className="text-yellow-400">[*] Found {reportData.unauthorized.length} policy breaches.</p>
              <p className="text-slate-500">[*] Compilation target: sftms_audit_report.txt</p>
              <p className="text-emerald-400">[✔] Report compilation completed.</p>
            </div>
          </div>
        </div>

        {/* Right Side: Text Report Frame */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-[#0f0f0f] rounded-xl p-5 border border-white/8 shadow-lg">
            <div className="flex items-center justify-between text-slate-500 text-[10px] font-mono border-b border-white/8 pb-2 mb-3">
              <span className="flex items-center gap-1.5 uppercase tracking-wide text-slate-400">
                <Printer className="w-3.5 h-3.5 text-sky-400" /> sftms_audit_report.txt
              </span>
              <span>UTF-8 Encoding</span>
            </div>
            
            {/* Plain text representation box */}
            <textarea
              readOnly
              value={compiledReportText}
              rows={21}
              className="w-full bg-[#050505] text-sky-300 font-mono text-xs focus:outline-none border-0 p-4 rounded-lg leading-relaxed overflow-y-auto"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
