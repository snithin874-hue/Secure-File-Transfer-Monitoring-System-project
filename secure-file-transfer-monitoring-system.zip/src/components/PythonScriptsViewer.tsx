/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { motion } from "motion/react";
import { 
  Terminal, 
  Copy, 
  Check, 
  Download, 
  ChevronRight, 
  HelpCircle,
  FileCode,
  Info
} from "lucide-react";
import { PYTHON_SCRIPTS, PythonScriptFile } from "../data/pythonScripts";

export default function PythonScriptsViewer() {
  const [activeFile, setActiveFile] = useState<PythonScriptFile>(PYTHON_SCRIPTS[2]); // default to monitor.py
  const [copying, setCopying] = useState(false);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(activeFile.code);
    setCopying(true);
    setTimeout(() => setCopying(false), 2000);
  };

  const handleDownloadFile = () => {
    const blob = new Blob([activeFile.code], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = activeFile.filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Intro Usage Guide Card */}
      <div className="bg-[#0f0f0f] text-slate-300 rounded-xl p-5 border border-white/8 shadow-md">
        <h3 className="text-sm font-semibold text-sky-400 flex items-center gap-1.5 uppercase font-mono tracking-wide">
          <Terminal className="w-4.5 h-4.5" /> Background Daemon Deployment
        </h3>
        <p className="text-xs text-slate-400 mt-1 max-w-2xl leading-relaxed">
          The SFTMS Python package observes raw operating system file activities on a directory tree, verifies cryptographic signatures, evaluates policies, and formats the rolling JSONL logs parsed by this React dashboard.
        </p>
        
        {/* Step-by-step CLI */}
        <div className="mt-4 border-t border-white/8 pt-3.5 space-y-2.5">
          <span className="text-[10px] uppercase font-bold text-slate-500 font-mono tracking-wider">How to Run locally:</span>
          <div className="bg-[#050505] border border-white/5 rounded-lg p-4 text-indigo-200 font-mono text-xs space-y-1">
            <p className="text-slate-500"># 1. Install Watchdog event observer library</p>
            <p className="text-emerald-400">pip install watchdog</p>
            <p className="text-slate-500 mt-2"># 2. Start monitoring your target directory</p>
            <p className="text-emerald-400">python monitor.py ~/Documents</p>
            <p className="text-slate-500 mt-2"># 3. Generate summary report at any time</p>
            <p className="text-emerald-400">python report.py</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Left Col: Scripts Tabs Selector */}
        <div className="space-y-3">
          <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono px-1">
            Available Python Modules
          </h4>
          <div className="space-y-2">
            {PYTHON_SCRIPTS.map((script) => (
              <button
                key={script.filename}
                onClick={() => setActiveFile(script)}
                className={`w-full text-left p-3.5 rounded-lg border text-xs transition-all duration-150 cursor-pointer flex items-center justify-between ${
                  activeFile.filename === script.filename 
                    ? "bg-white/5 border-sky-500/30 text-sky-400 shadow-xs font-semibold" 
                    : "bg-white/2 border-white/5 text-slate-400 hover:bg-white/5"
                }`}
              >
                <div className="flex items-center gap-2">
                  <FileCode className={`w-4 h-4 shrink-0 ${
                    activeFile.filename === script.filename ? "text-sky-400" : "text-slate-500"
                  }`} />
                  <span className="font-mono">{script.filename}</span>
                </div>
                <ChevronRight className="w-3.5 h-3.5 opacity-65" />
              </button>
            ))}
          </div>

          {/* Explanation Callout */}
          <div className="bg-[#0f0f0f] border border-white/8 p-4 rounded-lg text-xs text-slate-300 space-y-2">
            <h5 className="font-bold flex items-center gap-1 text-sky-400">
              <Info className="w-4 h-4 text-sky-400 shrink-0" /> Watchdog Observer
            </h5>
            <p className="leading-relaxed text-[11px] text-slate-400">
              The <code>monitor.py</code> daemon utilizes cross-platform filesystem hooks to receive high-frequency modify, rename, delete, and creation callbacks directly from the OS kernel.
            </p>
          </div>
        </div>

        {/* Right Col: Code Viewer Frame */}
        <div className="lg:col-span-3 space-y-4">
          <div className="bg-[#0f0f0f] rounded-xl border border-white/8 p-5 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/8 pb-3">
              <div>
                <h3 className="text-sm font-semibold font-mono text-white flex items-center gap-1.5">
                  📁 {activeFile.filename}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">{activeFile.description}</p>
              </div>

              <div className="flex gap-2 shrink-0">
                <button
                  onClick={handleCopyCode}
                  className="px-3 py-1.5 text-xs bg-white/5 hover:bg-white/10 border border-white/8 text-slate-300 font-semibold rounded-md flex items-center gap-1 transition-colors cursor-pointer"
                >
                  {copying ? (
                    <>
                      <Check className="w-3 h-3 text-emerald-400" /> Copied Code!
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3 text-sky-400" /> Copy Script
                    </>
                  )}
                </button>
                <button
                  onClick={handleDownloadFile}
                  className="px-3 py-1.5 text-xs bg-sky-500 hover:bg-sky-400 text-black font-semibold rounded-md flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <Download className="w-3 h-3" /> Download Script
                </button>
              </div>
            </div>

            {/* Code Content Container */}
            <div className="relative">
              <pre className="bg-[#050505] text-sky-300 border border-white/5 rounded-lg p-5 font-mono text-xs overflow-x-auto max-h-[500px] leading-relaxed select-all">
                <code>{activeFile.code}</code>
              </pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
