/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { SFTMSEvent, EventType, IntegrityStatus, AuthorizationStatus, SeverityLevel } from "../types";

// Helper to generate fake hash values
function genHash(seed: string): string {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    hash = (hash << 5) - hash + seed.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash).toString(16).padStart(8, "0") + "f3e82b712a4d0c283f6b92a34e8f19da562c64de2c7198fb901e";
}

// Iconic benchmark incidents (15 key events)
const ICONIC_INCIDENTS: SFTMSEvent[] = [
  {
    id: "evt-001",
    timestamp: "2026-06-25T14:23:10.421Z",
    event: EventType.MOVED,
    src: "/Users/admin/Confidential/Patents_Pending_2026.pdf",
    dest: "/media/usb0/Patents_Pending_2026.pdf",
    user: "jsmith",
    host: "WS-ENG-902",
    pid: 14210,
    process: "explorer.exe",
    hash_before: "d7a8f1e92d7a8f1e92d7a8f1e92d7a8f1e92d7a8f1e92d7a8f1e92d7a8f1e92a",
    hash_after: "d7a8f1e92d7a8f1e92d7a8f1e92d7a8f1e92d7a8f1e92d7a8f1e92d7a8f1e92a",
    integrity: IntegrityStatus.MATCH,
    sensitive: true,
    suspicious_destination: true,
    authorization: AuthorizationStatus.UNAUTHORIZED,
    severity: SeverityLevel.HIGH,
    details: "Critical patent document transferred directly to an external USB Mass Storage device."
  },
  {
    id: "evt-002",
    timestamp: "2026-06-25T15:10:05.112Z",
    event: EventType.MODIFIED,
    src: "/etc/pam.d/common-auth",
    user: "root",
    host: "SRV-PROD-AUTH01",
    pid: 9812,
    process: "malware_service",
    hash_before: "8a2f3c4e5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a",
    hash_after: "3f9e2d1c0b9a8f7e6d5c4b3a2f1e0d9c8b7a6f5e4d3c2b1a0f9e8d7c6b5a4f3e", // hash changed!
    integrity: IntegrityStatus.MISMATCH,
    sensitive: true,
    suspicious_destination: false,
    authorization: AuthorizationStatus.REVIEW,
    severity: SeverityLevel.HIGH,
    details: "System PAM authentication file modified. Integrity hash mismatch detected on critical system daemon."
  },
  {
    id: "evt-003",
    timestamp: "2026-06-25T16:04:42.889Z",
    event: EventType.DELETED,
    src: "/var/secure/db_backup_2026.sql",
    user: "unknown_daemon",
    host: "SRV-PROD-DB03",
    pid: 24391,
    process: "rm",
    hash_before: "5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3f4e5d6c7b8a9f0e1d2c3b4a5f6e",
    hash_after: "",
    integrity: IntegrityStatus.NA,
    sensitive: true,
    suspicious_destination: false,
    authorization: AuthorizationStatus.UNAUTHORIZED,
    severity: SeverityLevel.HIGH,
    details: "Sensitive SQL database backup file deleted without prior supervisor approval token."
  },
  {
    id: "evt-004",
    timestamp: "2026-06-25T17:42:19.301Z",
    event: EventType.MOVED,
    src: "/Users/finance/Confidential/Q2_Budget_Draft.xlsx",
    dest: "/Users/finance/Dropbox/Shared/Q2_Budget_Draft.xlsx",
    user: "mcollins",
    host: "WS-FIN-021",
    pid: 8812,
    process: "Dropbox.exe",
    hash_before: "fc82d7319082efd927a38fe89c28e9d8f8a29b0123cb23de4f981249fa6b2831",
    hash_after: "fc82d7319082efd927a38fe89c28e9d8f8a29b0123cb23de4f981249fa6b2831",
    integrity: IntegrityStatus.MATCH,
    sensitive: true,
    suspicious_destination: true,
    authorization: AuthorizationStatus.UNAUTHORIZED,
    severity: SeverityLevel.HIGH,
    details: "Financial spreadsheet budget draft moved to a synchronized personal cloud directory (Dropbox)."
  },
  {
    id: "evt-005",
    timestamp: "2026-06-25T18:15:33.004Z",
    event: EventType.CREATED,
    src: "/etc/cron.d/backdoor_trigger",
    user: "www-data",
    host: "SRV-WEB-01",
    pid: 3004,
    process: "nginx-worker",
    hash_before: "",
    hash_after: "6e2d1c0b9a8f7e6d5c4b3a2f1e0d9c8b7a6f5e4d3c2b1a0f9e8d7c6b5a4f3e2d",
    integrity: IntegrityStatus.MATCH,
    sensitive: true,
    suspicious_destination: false,
    authorization: AuthorizationStatus.REVIEW,
    severity: SeverityLevel.MEDIUM,
    details: "New cron job backdoor created inside sensitive folder by web server worker process."
  },
  {
    id: "evt-006",
    timestamp: "2026-06-25T20:30:11.912Z",
    event: EventType.MOVED,
    src: "/Users/research/Confidential/mRNA_Sequence_SFT.txt",
    dest: "/run/user/1000/gvfs/smb-share:server=untrusted_backup/mRNA_Sequence_SFT.txt",
    user: "dr_foster",
    host: "WS-LAB-04",
    pid: 1289,
    process: "gio",
    hash_before: "11a22b33c44d55e66f77a88b99c00d11e22f33a44b55c66d77e88f99a00b11c2",
    hash_after: "11a22b33c44d55e66f77a88b99c00d11e22f33a44b55c66d77e88f99a00b11c2",
    integrity: IntegrityStatus.MATCH,
    sensitive: true,
    suspicious_destination: true,
    authorization: AuthorizationStatus.UNAUTHORIZED,
    severity: SeverityLevel.HIGH,
    details: "Proprietary gene research sequence transferred to an unmapped Samba server share."
  },
  {
    id: "evt-007",
    timestamp: "2026-06-25T21:12:00.001Z",
    event: EventType.MODIFIED,
    src: "/etc/shadow",
    user: "root",
    host: "SRV-PROD-AUTH01",
    pid: 22001,
    process: "passwd",
    hash_before: "b10a2030405060708090a0b0c0d0e0f0102030405060708090a0b0c0d0e0f010",
    hash_after: "a090b0c0d0e0f0102030405060708090a0b0c0d0e0f0102030405060708090a0",
    integrity: IntegrityStatus.MATCH,
    sensitive: true,
    suspicious_destination: false,
    authorization: AuthorizationStatus.AUTHORIZED,
    severity: SeverityLevel.LOW,
    details: "Authorized update to user passwords database via standard password utility (passwd)."
  },
  {
    id: "evt-008",
    timestamp: "2026-06-25T23:05:14.502Z",
    event: EventType.DELETED,
    src: "/Users/admin/Confidential/Audit_Trail_2025.jsonl",
    user: "intruder_user",
    host: "WS-ENG-902",
    pid: 25441,
    process: "shred",
    hash_before: "ff88ee77dd66cc55bb44aa339922881100f9e8d7c6b5a4f3e2d1c0b9a8f7e6d5",
    hash_after: "",
    integrity: IntegrityStatus.NA,
    sensitive: true,
    suspicious_destination: false,
    authorization: AuthorizationStatus.UNAUTHORIZED,
    severity: SeverityLevel.HIGH,
    details: "Intentional scrubbing of historical event audit log using the destructive linux 'shred' tool."
  },
  {
    id: "evt-009",
    timestamp: "2026-06-26T01:15:22.110Z",
    event: EventType.CREATED,
    src: "/Users/admin/OneDrive/Shared/Patents_Pending_2026.pdf",
    user: "jsmith",
    host: "WS-ENG-902",
    pid: 14210,
    process: "OneDrive.exe",
    hash_before: "",
    hash_after: "d7a8f1e92d7a8f1e92d7a8f1e92d7a8f1e92d7a8f1e92d7a8f1e92d7a8f1e92a",
    integrity: IntegrityStatus.MATCH,
    sensitive: true,
    suspicious_destination: true,
    authorization: AuthorizationStatus.UNAUTHORIZED,
    severity: SeverityLevel.HIGH,
    details: "Sensitive patent document placed into OneDrive shared synchronization directory."
  },
  {
    id: "evt-010",
    timestamp: "2026-06-26T02:45:00.672Z",
    event: EventType.MODIFIED,
    src: "/var/secure/credit_cards.csv",
    user: "malware_script",
    host: "SRV-PROD-DB03",
    pid: 31012,
    process: "python3",
    hash_before: "cc44dd55ee66ff77aa88bb99cc00dd11ee22ff33aa44bb55cc66dd77ee88ff99",
    hash_after: "aa11bb22cc33dd44ee55ff66aa77bb88cc99dd00ee11ff22aa33bb44ee55ff66",
    integrity: IntegrityStatus.MISMATCH,
    sensitive: true,
    suspicious_destination: false,
    authorization: AuthorizationStatus.UNAUTHORIZED,
    severity: SeverityLevel.HIGH,
    details: "PCI-DSS protected credit card ledger modified by unauthorized script outside of transactional hours."
  },
  {
    id: "evt-011",
    timestamp: "2026-06-26T03:00:10.005Z",
    event: EventType.MOVED,
    src: "/Users/research/Confidential/Formula_X.docx",
    dest: "/media/usb1/Formula_X.docx",
    user: "dr_foster",
    host: "WS-LAB-04",
    pid: 1402,
    process: "explorer.exe",
    hash_before: "99aa88bb77cc66dd55ee44ff33aa22bb11cc00dd99ee88ff77aa66bb55cc44dd",
    hash_after: "99aa88bb77cc66dd55ee44ff33aa22bb11cc00dd99ee88ff77aa66bb55cc44dd",
    integrity: IntegrityStatus.MATCH,
    sensitive: true,
    suspicious_destination: true,
    authorization: AuthorizationStatus.UNAUTHORIZED,
    severity: SeverityLevel.HIGH,
    details: "Chemistry formulation document copied directly to external USB media."
  },
  {
    id: "evt-012",
    timestamp: "2026-06-26T03:40:55.120Z",
    event: EventType.MODIFIED,
    src: "/etc/ssh/sshd_config",
    user: "root",
    host: "SRV-WEB-01",
    pid: 1845,
    process: "nano",
    hash_before: "0102030405060708090a0b0c0d0e0f0102030405060708090a0b0c0d0e0f0102",
    hash_after: "0102030405060708090a0b0c0d0e0f0102030405060708090a0b0c0d0e0f0102", // hash matches, maybe saved without modifications
    integrity: IntegrityStatus.MATCH,
    sensitive: true,
    suspicious_destination: false,
    authorization: AuthorizationStatus.AUTHORIZED,
    severity: SeverityLevel.LOW,
    details: "SSHD configuration opened and saved by systems administrator without changes."
  },
  {
    id: "evt-013",
    timestamp: "2026-06-26T04:10:00.000Z",
    event: EventType.CREATED,
    src: "/var/secure/ssh_key_compromise",
    user: "hacker",
    host: "SRV-WEB-01",
    pid: 32098,
    process: "scp",
    hash_before: "",
    hash_after: "7766554433221100eeddccbbaa99887766554433221100eeddccbbaa99887766",
    integrity: IntegrityStatus.MATCH,
    sensitive: true,
    suspicious_destination: false,
    authorization: AuthorizationStatus.UNAUTHORIZED,
    severity: SeverityLevel.HIGH,
    details: "Rogue SSH keys uploaded to secure backup directory using scp from a remote foreign host."
  },
  {
    id: "evt-014",
    timestamp: "2026-06-26T04:55:12.304Z",
    event: EventType.DELETED,
    src: "/Users/admin/Confidential/Employees_2026.xlsx",
    user: "angry_leaver",
    host: "WS-HR-101",
    pid: 5412,
    process: "rm",
    hash_before: "a0b1c2d3e4f5a0b1c2d3e4f5a0b1c2d3e4f5a0b1c2d3e4f5a0b1c2d3e4f5a0b1",
    hash_after: "",
    integrity: IntegrityStatus.NA,
    sensitive: true,
    suspicious_destination: false,
    authorization: AuthorizationStatus.UNAUTHORIZED,
    severity: SeverityLevel.HIGH,
    details: "Employee salary details database deleted by a disgruntled employee right before leaving the company."
  },
  {
    id: "evt-015",
    timestamp: "2026-06-26T05:12:18.991Z",
    event: EventType.MOVED,
    src: "/Users/research/Confidential/Patent_Images.zip",
    dest: "/Users/research/GoogleDrive/Patent_Images.zip",
    user: "dr_foster",
    host: "WS-LAB-04",
    pid: 1402,
    process: "googledrivesync.exe",
    hash_before: "3a4b5c6d7e8f3a4b5c6d7e8f3a4b5c6d7e8f3a4b5c6d7e8f3a4b5c6d7e8f3a4b",
    hash_after: "3a4b5c6d7e8f3a4b5c6d7e8f3a4b5c6d7e8f3a4b5c6d7e8f3a4b5c6d7e8f3a4b",
    integrity: IntegrityStatus.MATCH,
    sensitive: true,
    suspicious_destination: true,
    authorization: AuthorizationStatus.UNAUTHORIZED,
    severity: SeverityLevel.HIGH,
    details: "Compressed research assets moved to Google Drive cloud sync directory without administrative authorization."
  }
];

// Generate 105 standard routine events to complete 120 total events
const SYSTEM_PROCESSES = ["git", "node", "tsc", "vite", "systemd", "dockerd", "chrome", "code", "bash", "cargo", "python3"];
const USERS = ["alice", "bob", "developer", "tester", "sysadmin", "jenkins_agent", "db_cleaner", "analyst"];
const HOSTS = ["WS-DEV-001", "WS-DEV-002", "SRV-TEST-02", "CI-BUILD-04", "WS-MGR-31", "SRV-LOG-01"];
const FILE_EXTENSIONS = [".ts", ".js", ".tsx", ".css", ".json", ".md", ".log", ".tmp", ".o", ".py", ".rs", ".yml"];

function generateRoutineEvents(): SFTMSEvent[] {
  const events: SFTMSEvent[] = [];
  const totalRoutine = 105;
  const startTime = new Date("2026-06-24T08:00:00.000Z");

  for (let i = 0; i < totalRoutine; i++) {
    // Distribute events over June 24th, 25th, and 26th
    const eventTime = new Date(startTime.getTime() + i * 920000); // spread over several days
    const eventTypeRand = Math.random();
    let eventType = EventType.MODIFIED;
    if (eventTypeRand < 0.2) eventType = EventType.CREATED;
    else if (eventTypeRand < 0.35) eventType = EventType.DELETED;
    else if (eventTypeRand < 0.5) eventType = EventType.MOVED;

    const user = USERS[i % USERS.length];
    const host = HOSTS[i % HOSTS.length];
    const proc = SYSTEM_PROCESSES[i % SYSTEM_PROCESSES.length];
    const pid = 1000 + (i * 37) % 28000;
    const ext = FILE_EXTENSIONS[i % FILE_EXTENSIONS.length];

    // Build realistic routine paths
    let src = `/Users/${user}/projects/webapp/src/components/button${ext}`;
    if (ext === ".log") src = `/var/log/nginx/access_log-${i % 4}.log`;
    else if (ext === ".tmp") src = `/tmp/session_cache_${i}.tmp`;
    else if (ext === ".o") src = `/Users/${user}/projects/c_module/build/main.o`;

    let dest: string | undefined = undefined;
    if (eventType === EventType.MOVED) {
      dest = src.replace("projects", "backup_projects");
    }

    // Standard properties
    const beforeHash = eventType === EventType.CREATED ? "" : genHash(`before-${i}`);
    const afterHash = eventType === EventType.DELETED ? "" : (Math.random() > 0.3 && eventType === EventType.MODIFIED ? genHash(`after-changed-${i}`) : beforeHash);

    const integrity = eventType === EventType.DELETED 
      ? IntegrityStatus.NA 
      : (beforeHash && afterHash && beforeHash !== afterHash ? IntegrityStatus.MISMATCH : IntegrityStatus.MATCH);

    // Routine events are never sensitive or suspicious, keeping low severity
    events.push({
      id: `evt-routine-${100 + i}`,
      timestamp: eventTime.toISOString(),
      event: eventType,
      src,
      dest,
      user,
      host,
      pid,
      process: proc,
      hash_before: beforeHash,
      hash_after: afterHash,
      integrity,
      sensitive: false,
      suspicious_destination: false,
      authorization: AuthorizationStatus.AUTHORIZED,
      severity: SeverityLevel.LOW,
      details: `Routine system activity: ${eventType} file on ${host}.`
    });
  }

  return events;
}

// Combine and sort events chronologically
export const INITIAL_EVENTS: SFTMSEvent[] = [...ICONIC_INCIDENTS, ...generateRoutineEvents()].sort(
  (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime() // newest first for active viewing
);
