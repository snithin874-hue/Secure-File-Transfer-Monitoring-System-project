/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface PythonScriptFile {
  filename: string;
  description: string;
  code: string;
}

export const PYTHON_SCRIPTS: PythonScriptFile[] = [
  {
    filename: "policy.py",
    description: "Policy classification engine. Matches path patterns against SENSITIVE_DIRS and checks for SUSPICIOUS_DESTINATIONS.",
    code: `import os

# SFTMS Policy Configuration Engine
SENSITIVE_DIRS = [
    "/etc/shadow",
    "/etc/pam.d",
    "/var/secure",
    "confidential",
    "patent",
    "restricted"
]

SUSPICIOUS_DESTINATIONS = [
    "usb",
    "media",
    "dropbox",
    "onedrive",
    "googledrive",
    "smb-share",
    "nfs"
]

def is_sensitive(path: str) -> bool:
    """Check if the given path contains any sensitive patterns."""
    path_lower = path.lower()
    return any(pattern in path_lower for pattern in SENSITIVE_DIRS)

def is_suspicious_destination(dest_path: str) -> bool:
    """Check if the destination path points to an untrusted/monitored medium."""
    if not dest_path:
        return False
    dest_lower = dest_path.lower()
    return any(pattern in dest_lower for pattern in SUSPICIOUS_DESTINATIONS)

def evaluate_event(event_type: str, src_path: str, dest_path: str = None) -> dict:
    """
    Evaluates file movement rules and returns authorization, severity, and status flags.
    """
    sensitive = is_sensitive(src_path) or (dest_path and is_sensitive(dest_path))
    suspicious = is_suspicious_destination(dest_path) if dest_path else False
    
    auth = "AUTHORIZED"
    severity = "LOW"
    
    if sensitive:
        if event_type == "deleted":
            auth = "UNAUTHORIZED"
            severity = "HIGH"
        elif event_type == "moved" and suspicious:
            auth = "UNAUTHORIZED"
            severity = "HIGH"
        elif event_type == "moved":
            auth = "REVIEW"
            severity = "MEDIUM"
        elif event_type in ["created", "modified"]:
            auth = "REVIEW"
            severity = "MEDIUM"
    elif suspicious:
        auth = "REVIEW"
        severity = "LOW"
        
    return {
        "sensitive": sensitive,
        "suspicious_destination": suspicious,
        "authorization": auth,
        "severity": severity
    }
`
  },
  {
    filename: "hashing.py",
    description: "Cryptographic hash utilities. Computes streaming SHA-256 signatures to verify file integrity and prevent tamper detection gaps.",
    code: `import hashlib
import os

def calculate_sha256(file_path: str) -> str:
    """
    Computes the SHA-256 hash of a file using streaming chunks.
    Returns empty string if file is missing, deleted, or unreadable.
    """
    if not os.path.exists(file_path) or os.path.isdir(file_path):
        return ""
        
    sha256_hash = hashlib.sha256()
    try:
        with open(file_path, "rb") as f:
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
        return sha256_hash.hexdigest()
    except (PermissionError, FileNotFoundError):
        return "UNKNOWN_LOCKED"
    except Exception as e:
        return f"ERROR_{str(e)[:15]}"

def verify_integrity(hash_before: str, hash_after: str, event_type: str) -> str:
    """
    Compares file signatures. Returns MATCH, MISMATCH, or N/A.
    """
    if event_type == "deleted":
        return "N/A"
    if not hash_before or not hash_after:
        return "UNKNOWN"
    if hash_before == hash_after:
        return "MATCH"
    else:
        return "MISMATCH"
`
  },
  {
    filename: "monitor.py",
    description: "Main Watchdog daemon. Watches specified directories in real time, computes signatures, queries policies, and logs events.",
    code: `import os
import sys
import time
import json
import socket
import getpass
from datetime import datetime
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

import policy
import hashing

# Setup target logs
LOG_DIR = "./sftms_out"
os.makedirs(LOG_DIR, exist_ok=True)

EVENTS_JSON = os.path.join(LOG_DIR, "sftms_events.json")
EVENTS_LOG = os.path.join(LOG_DIR, "sftms_events.log")
ALERTS_JSON = os.path.join(LOG_DIR, "sftms_alerts.json")

class SFTMSHandler(FileSystemEventHandler):
    def __init__(self):
        super().__init__()
        self.host = socket.gethostname()
        self.user = getpass.getuser()
        self.pid = os.getpid()
        # Keep an in-memory database of last known file hashes to detect modification integrity
        self.hash_db = {}

    def log_event(self, event_type: str, src: str, dest: str = None):
        # Ignore directories
        if os.path.isdir(src) or (dest and os.path.isdir(dest)):
            return

        # Calculate hashes
        hash_before = self.hash_db.get(src, "")
        hash_after = hashing.calculate_sha256(dest if dest else src)
        
        # If it's a create, before-hash is blank. Update in-memory DB
        if event_type == "created":
            hash_before = ""
            self.hash_db[src] = hash_after
        elif event_type == "modified":
            # Before is what we last saw. If none, calculate
            if not hash_before:
                hash_before = "PRE_MODIFY_UNKNOWN"
            self.hash_db[src] = hash_after
        elif event_type == "deleted":
            hash_after = ""
            if src in self.hash_db:
                del self.hash_db[src]
        elif event_type == "moved":
            # Relocate hash key
            self.hash_db[dest] = hash_after
            if src in self.hash_db:
                del self.hash_db[src]

        # Audit with Policy Engine
        decision = policy.evaluate_event(event_type, src, dest)
        integrity = hashing.verify_integrity(hash_before, hash_after, event_type)
        
        # If we see a mismatch, flag review/unauthorized based on severity
        if integrity == "MISMATCH" and decision["sensitive"]:
            decision["authorization"] = "UNAUTHORIZED"
            decision["severity"] = "HIGH"

        # Create structured schema
        audit_event = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "event": event_type,
            "src": src,
            "dest": dest,
            "user": self.user,
            "host": self.host,
            "pid": self.pid,
            "process": sys.executable.split("/")[-1],
            "hash_before": hash_before,
            "hash_after": hash_after,
            "integrity": integrity,
            "sensitive": decision["sensitive"],
            "suspicious_destination": decision["suspicious_destination"],
            "authorization": decision["authorization"],
            "severity": decision["severity"]
        }

        # Append to JSONL File
        with open(EVENTS_JSON, "a") as f:
            f.write(json.dumps(audit_event) + "\\n")

        # Append to Human Readable rolling log
        log_line = f"[{audit_event['timestamp']}] {audit_event['severity']} - {audit_event['authorization'].upper()} | {user}@{host} | {event_type.upper()} {src}"
        if dest:
            log_line += f" -> {dest}"
        log_line += f" | Integrity: {integrity}\\n"

        with open(EVENTS_LOG, "a") as f:
            f.write(log_line)

        # Write alerts separately if unauthorized or review required
        if decision["authorization"] in ["UNAUTHORIZED", "REVIEW"]:
            with open(ALERTS_JSON, "a") as f:
                f.write(json.dumps(audit_event) + "\\n")
            print(f"⚠️  ALERT: {decision['authorization']} Transfer! {src} -> {dest if dest else 'None'}")

    def on_created(self, event):
        self.log_event("created", event.src_path)

    def on_modified(self, event):
        self.log_event("modified", event.src_path)

    def on_deleted(self, event):
        self.log_event("deleted", event.src_path)

    def on_moved(self, event):
        self.log_event("moved", event.src_path, event.dest_path)

def monitor_directory(target_path):
    print(f"[*] Starting Secure File Transfer Monitor...")
    print(f"[*] Target Directory: {os.path.abspath(target_path)}")
    print(f"[*] Logging events to: {LOG_DIR}")
    
    event_handler = SFTMSHandler()
    observer = Observer()
    observer.schedule(event_handler, path=target_path, recursive=True)
    observer.start()
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\\n[*] Stopping Monitor...")
        observer.stop()
    observer.join()

if __name__ == "__main__":
    path_to_watch = sys.argv[1] if len(sys.argv) > 1 else "."
    monitor_directory(path_to_watch)
`
  },
  {
    filename: "report.py",
    description: "Post-incident audit reporting utility. Reads structured JSONL, computes statistical summaries, and writes a professional text-formatted report.",
    code: `import json
import os
import sys
from collections import Counter

def generate_report(out_dir="./sftms_out"):
    events_json = os.path.join(out_dir, "sftms_events.json")
    report_file = os.path.join(out_dir, "sftms_audit_report.txt")
    
    if not os.path.exists(events_json):
        print(f"[!] Error: {events_json} not found. No events to audit.")
        return
        
    events = []
    with open(events_json, "r") as f:
        for line in f:
            if line.strip():
                events.append(json.loads(line))
                
    total_events = len(events)
    unauthorized = [e for e in events if e["authorization"] == "UNAUTHORIZED"]
    reviews = [e for e in events if e["authorization"] == "REVIEW"]
    mismatches = [e for e in events if e["integrity"] == "MISMATCH"]
    sensitive_touches = [e for e in events if e["sensitive"]]
    
    # Process analytics
    user_counts = Counter([e["user"] for e in events])
    event_counts = Counter([e["event"] for e in events])
    process_counts = Counter([e["process"] for e in events])
    
    report_text = f"""================================================================================
SECURE FILE TRANSFER MONITORING SYSTEM (SFTMS) - COMPLIANCE AUDIT REPORT
Generated on: {os.popen("date").read().strip()}
Target Output: {os.path.abspath(out_dir)}
================================================================================

1. EXECUTIVE SUMMARY
---------------------
The system analyzed {total_events} cumulative filesystem events.
• Unauthorized Transfers Detected: {len(unauthorized)} (CRITICAL ACTION REQUIRED)
• Pending Security Reviews: {len(reviews)} (POTENTIAL RISK)
• Integrity Violations (Hash Mismatch): {len(mismatches)} (SUSPECTED TAMPERING)
• Restricted Files Accessed/Moved: {len(sensitive_touches)}

2. THREAT COUNTERMEASURES & COMPLIANCE GAP ANALYSIS
----------------------------------------------------
"""
    if unauthorized:
        report_text += "🔴 WARNING: HIGH SEVERITY INSIDER THREATS OR EXFILTRATION DETECTED.\\n"
        for idx, ue in enumerate(unauthorized, 1):
            report_text += f"   [{idx}] {ue['timestamp']} - User '{ue['user']}' moved sensitive file:\\n"
            report_text += f"       Source: {ue['src']}\\n"
            if ue.get('dest'):
                report_text += f"       Destination: {ue['dest']}\\n"
            report_text += f"       Action: {ue['event'].upper()} | Hash Integrity: {ue['integrity']}\\n\\n"
    else:
        report_text += "🟢 NO DIRECT POLICY VIOLATIONS DETECTED. File exfiltration rules fully satisfied.\\n\\n"
        
    if mismatches:
        report_text += "⚠️ SECURITY RISK: SYSTEM OR SENSITIVE FILE INTEGRITY TAMPERED\\n"
        for idx, me in enumerate(mismatches, 1):
            report_text += f"   [{idx}] {me['timestamp']} - Integrity compromised for file: {me['src']}\\n"
            report_text += f"       Original Hash: {me['hash_before'][:16]}...\\n"
            report_text += f"       Modified Hash: {me['hash_after'][:16]}...\\n\\n"
            
    report_text += f"""3. ACTIVITY STATISTICS
----------------------
A. Event Types:
{json.dumps(dict(event_counts), indent=4)}

B. Top Contributing Accounts:
{json.dumps(dict(user_counts.most_common(5)), indent=4)}

C. Top Accessing Processes:
{json.dumps(dict(process_counts.most_common(5)), indent=4)}

4. BLUE-TEAM REMEDIATION RECOMMENDATIONS
----------------------------------------
1. [IMMEDIATE] Revoke active USB storage access permission tokens for suspicious workstations.
2. [IMMEDIATE] Re-image workstations exhibiting unauthorized PAM module hashes (SSHD or common-auth modifications).
3. Implement strict role-based folder lockouts on directories matching 'confidential'.
4. Deploy continuous background monitoring using watchdog service as a persistent systemd service.

================================================================================
END OF AUDIT COMPLIANCE REPORT - CONFIDENTIAL
================================================================================
"""
    with open(report_file, "w") as f:
        f.write(report_text)
        
    print(f"[*] Report compiled successfully. Written to: {report_file}")

if __name__ == "__main__":
    out_path = sys.argv[1] if len(sys.argv) > 1 else "./sftms_out"
    generate_report(out_path)
`
  }
];
