/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum EventType {
  CREATED = "created",
  MODIFIED = "modified",
  MOVED = "moved",
  DELETED = "deleted",
}

export enum IntegrityStatus {
  MATCH = "MATCH",
  MISMATCH = "MISMATCH",
  NA = "N/A",
  UNKNOWN = "UNKNOWN",
}

export enum AuthorizationStatus {
  AUTHORIZED = "AUTHORIZED",
  REVIEW = "REVIEW",
  UNAUTHORIZED = "UNAUTHORIZED",
}

export enum SeverityLevel {
  LOW = "LOW",
  MEDIUM = "MEDIUM",
  HIGH = "HIGH",
}

export interface SFTMSEvent {
  id: string; // React-specific unique ID
  timestamp: string; // ISO-8601 UTC time
  event: EventType;
  src: string;
  dest?: string;
  user: string;
  host: string;
  pid: number;
  process: string;
  hash_before: string;
  hash_after: string;
  integrity: IntegrityStatus;
  sensitive: boolean;
  suspicious_destination: boolean;
  authorization: AuthorizationStatus;
  severity: SeverityLevel;
  details?: string;
}

export interface PolicyRule {
  id: string;
  pattern: string;
  description: string;
  type: "SENSITIVE_DIR" | "SUSPICIOUS_DEST";
  severityOnTrigger: SeverityLevel;
}
